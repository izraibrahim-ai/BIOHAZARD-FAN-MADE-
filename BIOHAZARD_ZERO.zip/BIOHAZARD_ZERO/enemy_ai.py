#!/usr/bin/env python3
# enemy_ai.py — AI musuh: chase player dengan batas jarak

import random

AGGRO_RANGE  = 6   # jarak musuh mulai aggro/ngejar
CHASE_LIMIT  = 4   # max tile yang bisa dikejar dari posisi spawn awal

WALKABLE = {'.', '[', '/', '>', '<', '^', '%', '?'}

def update_enemies(dungeon, player, msg_fn):
    for entity in dungeon.entities:
        if not entity.alive:
            continue

        dist_to_player = _dist(entity.x, entity.y, player.x, player.y)

        # Sudah di samping player — combat ditangani move_player
        if dist_to_player <= 1.5:
            continue

        # Inisiasi spawn position pertama kali
        if not hasattr(entity, 'spawn_x'):
            entity.spawn_x = entity.x
            entity.spawn_y = entity.y

        dist_from_spawn = _dist(entity.x, entity.y, entity.spawn_x, entity.spawn_y)

        if dist_to_player <= AGGRO_RANGE:
            # Masih dalam batas chase — ngejar
            if dist_from_spawn < CHASE_LIMIT:
                _chase(entity, player.x, player.y, dungeon)
            else:
                # Sudah terlalu jauh dari spawn — balik ke spawn
                _chase(entity, entity.spawn_x, entity.spawn_y, dungeon)
        else:
            # Player jauh — patrol kecil di sekitar spawn
            if dist_from_spawn > 2:
                # Balik ke spawn
                _chase(entity, entity.spawn_x, entity.spawn_y, dungeon)
            elif random.random() < 0.35:
                _patrol(entity, dungeon)


def _dist(x1, y1, x2, y2):
    return abs(x1 - x2) + abs(y1 - y2)


def _chase(entity, tx, ty, dungeon):
    ex, ey = entity.x, entity.y
    dx = 0 if tx == ex else (1 if tx > ex else -1)
    dy = 0 if ty == ey else (1 if ty > ey else -1)

    candidates = []
    if dx and dy: candidates.append((dx, dy))
    if dx:        candidates.append((dx, 0))
    if dy:        candidates.append((0, dy))
    for d in [(1,0),(-1,0),(0,1),(0,-1)]:
        if d not in candidates:
            candidates.append(d)

    for mdx, mdy in candidates:
        nx, ny = ex + mdx, ey + mdy
        if _can_step(nx, ny, dungeon, entity):
            entity.x, entity.y = nx, ny
            return


def _patrol(entity, dungeon):
    dirs = [(0,1),(0,-1),(1,0),(-1,0)]
    random.shuffle(dirs)
    for dx, dy in dirs:
        nx, ny = entity.x + dx, entity.y + dy
        if _can_step(nx, ny, dungeon, entity):
            entity.x, entity.y = nx, ny
            return


def _can_step(nx, ny, dungeon, self_entity):
    if not (0 <= nx < 60 and 0 <= ny < 22):
        return False
    t = dungeon.tile_at(nx, ny)
    if t not in WALKABLE:
        return False
    for e in dungeon.entities:
        if e is not self_entity and e.alive and e.x == nx and e.y == ny:
            return False
    return True
