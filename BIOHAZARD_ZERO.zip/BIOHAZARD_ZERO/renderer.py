#!/usr/bin/env python3
# renderer.py — Render peta NetHack style dengan FOV & sidebar — RE9 EDITION

from utils import C
from missions import mission_hud
from data  import SYM_COLOR
from dungeon import MAP_W, MAP_H, TILE_FLOOR, TILE_EMPTY, TILE_TRAP, TILE_DOOR_S, TILE_DOOR_O

FOV_RADIUS = 999  # Seluruh map terlihat

# ── Tile render map: tile asli -> (warna, simbol_display) ─────────────────────
TILE_RENDER = {
    '─':  (C.GRAY,              '─'),
    '│':  (C.GRAY,              '│'),
    '┌':  (C.GRAY,              '┌'),
    '┐':  (C.GRAY,              '┐'),
    '└':  (C.GRAY,              '└'),
    '┘':  (C.GRAY,              '┘'),
    '.':  (C.GRAY + C.DIM,      '·'),   # lantai → titik kecil
    '[':  (C.YELLOW + C.BOLD,   '['),   # pintu kiri
    ']':  (C.YELLOW + C.BOLD,   ']'),   # pintu kanan (dekor)
    '?':  (C.CYAN  + C.BOLD,   '?'),   # kertas/catatan
    '>':  (C.WHITE + C.BOLD,    '>'),
    '<':  (C.WHITE + C.BOLD,    '<'),
    '^':  (C.RED + C.BOLD,      '^'),
    '%':  (C.RED,               '%'),
    '·':  (C.GRAY + C.DIM,      '·'),
    ' ':  ('',                  ' '),
}

def _enemy_color(pct):
    if pct > 0.6:  return C.GREEN
    if pct > 0.3:  return C.YELLOW
    return C.RED + C.BOLD


def compute_fov(dungeon, px, py, radius=FOV_RADIUS):
    visible = set()
    for y in range(MAP_H):
        for x in range(MAP_W):
            if dungeon.map[y][x] != ' ':
                visible.add((x, y))
    visible.add((px, py))
    return visible


def render(dungeon, player, messages, seen):
    visible = compute_fov(dungeon, player.x, player.y)
    seen.update(visible)

    # ── Build map lines ───────────────────────────────────────────────────────
    lines = []
    for y in range(MAP_H):
        line = ''
        for x in range(MAP_W):
            is_vis = (x, y) in visible

            # Player
            if x == player.x and y == player.y:
                line += C.CYAN + C.BOLD + '@' + C.RESET
                continue

            if is_vis:
                # Entity
                e = dungeon.entity_at(x, y)
                if e:
                    from enemy_ai import _dist, AGGRO_RANGE
                    dist = _dist(e.x, e.y, player.x, player.y)
                    pct  = e.hp / max(1, e.data['hp'])
                    col  = _enemy_color(pct)
                    if e.data.get('is_boss'):
                        col = C.RED + C.BOLD + C.BLINK
                    elif dist <= AGGRO_RANGE:
                        col = C.RED + C.BOLD
                    line += col + e.sym + C.RESET
                    continue

                # Item
                it = dungeon.item_at(x, y)
                if it:
                    col = SYM_COLOR.get(it.sym, C.WHITE)
                    line += col + it.sym + C.RESET
                    continue

                # Gold
                g = dungeon.gold_at(x, y)
                if g:
                    line += C.YELLOW + C.BOLD + '$' + C.RESET
                    continue

            # Terrain
            tile = dungeon.map[y][x]
            if tile in TILE_RENDER:
                col, sym = TILE_RENDER[tile]
                line += (col + sym + C.RESET) if col else sym
            else:
                col = SYM_COLOR.get(tile, C.WHITE)
                line += col + tile + C.RESET

        lines.append(line)

    # ── Sidebar ───────────────────────────────────────────────────────────────
    sb = _build_sidebar(player, dungeon)

    # ── Header ────────────────────────────────────────────────────────────────
    from data import get_floor_info
    info       = get_floor_info(player.floor)
    boss_floor = (player.floor % 2 == 0)
    border_col = C.RED if boss_floor else C.GRAY

    title      = f" {info['simbol']} {info['nama'].upper()}  ·  Floor {player.floor}/6  ·  {player.icon} {player.kelas} Lv{player.level}"
    title_vis  = title  # raw chars for display; ANSI-free here
    PAD        = 62
    pad_spaces = max(0, PAD - len(title_vis))

    print(f"{border_col}╔{'═'*PAD}╗{C.RESET}")
    boss_warn  = f"  {C.RED+C.BLINK}⚠ BOSS FLOOR!{C.RESET}" if boss_floor else ""
    print(f"{border_col}║{C.RESET}{C.BOLD}{title}{' '*pad_spaces}{C.RESET}{boss_warn}{border_col}║{C.RESET}")
    print(f"{border_col}╠{'═'*PAD}╣{C.RESET}")

    # Map + sidebar
    for i, mapline in enumerate(lines):
        side = sb[i] if i < len(sb) else ''
        print(mapline + '  ' + side)

    # ── Message log ───────────────────────────────────────────────────────────
    print(f"{C.GRAY}╠{'─'*PAD}╣{C.RESET}")
    msg_show = messages[-4:] if messages else []
    for m in msg_show:
        print(f" {m}")
    for _ in range(4 - len(msg_show)):
        print()
    print(f"{C.GRAY}╚{'─'*PAD}╝{C.RESET}")

    # ── Control hint ──────────────────────────────────────────────────────────
    print(
        f" {C.YELLOW}hjkl{C.RESET}/{C.YELLOW}←↑↓→{C.RESET}:Gerak"
        f"  {C.WHITE}>{C.RESET}/{C.WHITE}<{C.RESET}:Tangga"
        f"  {C.WHITE}g{C.RESET}:Ambil"
        f"  {C.WHITE}i{C.RESET}:Inv"
        f"  {C.WHITE}a{C.RESET}:Pakai"
        f"  {C.WHITE}e{C.RESET}:Equip"
        f"  {C.WHITE}x{C.RESET}:Look"
        f"  {C.WHITE}S{C.RESET}:Save"
        f"  {C.WHITE}Q{C.RESET}:Quit"
        f"  {C.WHITE}?{C.RESET}:Help"
        f"  {C.YELLOW}m{C.RESET}:Misi"
    )

    return visible


def _build_sidebar(p, dungeon):
    lines = []

    def L(s=''):
        return s

    lines.append(L(f"{C.RED}╔{'═'*22}╗{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET}{C.CYAN+C.BOLD} {p.icon} {p.nama[:16]}{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.WHITE}{p.kelas[:12]}{C.RESET}  {C.YELLOW}Lv{p.level}{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.GRAY}XP: {p.xp}/{p.xp_needed()}{C.RESET}"))
    lines.append(L(f"{C.RED}╠{'═'*22}╣{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} HP {p.hp_bar(11)}"))
    lines.append(L(f"{C.RED}║{C.RESET} MP {p.mp_bar(11)}"))
    lines.append(L(f"{C.RED}╠{'═'*22}╣{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.YELLOW}ATK{C.RESET} {p.total_atk:<3}  {C.BLUE}DEF{C.RESET} {p.total_def:<3}  {C.GREEN}SPD{C.RESET} {p.spd}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.YELLOW}Gold{C.RESET} {p.gold:<6}  {C.RED}Kills{C.RESET} {p.kills}"))

    # Status
    sp = []
    if p.poisoned:  sp.append(f"{C.MAGENTA}☠POI{C.RESET}")
    if p.bleeding:  sp.append(f"{C.RED}🩸BLD{C.RESET}")
    if p.guarding:  sp.append(f"{C.BLUE}🛡GRD{C.RESET}")
    if p.evading:   sp.append(f"{C.GREEN}💨EVD{C.RESET}")
    st_str = ' '.join(sp) if sp else f"{C.GREEN}● OK{C.RESET}"
    lines.append(L(f"{C.RED}║{C.RESET} {st_str}"))

    lines.append(L(f"{C.RED}╠{'═'*22}╣{C.RESET}"))
    sw = (p.weapon['nama'][:14]) if p.weapon else 'none'
    ar = (p.armor['nama'][:14])  if p.armor  else 'none'
    lines.append(L(f"{C.RED}║{C.RESET} {C.YELLOW}){C.RESET} {C.WHITE}{sw}{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.BLUE}[{C.RESET} {C.WHITE}{ar}{C.RESET}"))

    lines.append(L(f"{C.RED}╠{'═'*22}╣{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.GRAY}> Tangga turun{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.GRAY}< Tangga naik{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.GRAY}$ Gold  ! Obat{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.GRAY}) Senjata [ Armor{C.RESET}"))
    lines.append(L(f"{C.RED}╠{'═'*22}╣{C.RESET}"))

    # Indikator save terakhir
    last_save = getattr(p, '_last_save_time', None)
    if last_save:
        lines.append(L(f"{C.RED}║{C.RESET} {C.GREEN}💾 SAVED {last_save}{C.RESET}"))
    else:
        lines.append(L(f"{C.RED}║{C.RESET} {C.YELLOW}💾 Belum disimpan!{C.RESET}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.GRAY}[S] simpan sekarang{C.RESET}"))
    lines.append(L(f"{C.RED}╠{'═'*22}╣{C.RESET}"))

    # Misi aktif
    mhud = mission_hud(p)
    for mline in mhud:
        lines.append(L(f"{C.RED}║{C.RESET}{mline}"))
    lines.append(L(f"{C.RED}║{C.RESET} {C.GRAY}[m] lihat semua misi{C.RESET}"))
    lines.append(L(f"{C.RED}╠{'═'*22}╣{C.RESET}"))

    # Enemy list
    alive = [e for e in dungeon.entities if e.alive]
    if alive:
        lines.append(L(f"{C.RED}║{C.RESET} {C.RED}⚠ MUSUH [{len(alive)}]{C.RESET}"))
        for e in alive[:4]:
            pct    = e.hp / max(1, e.data['hp'])
            ec     = _enemy_color(pct)
            col    = SYM_COLOR.get(e.sym, C.WHITE)
            bar_len = 8
            filled  = int(pct * bar_len)
            hp_bar  = ec + '█' * filled + C.GRAY + '░' * (bar_len - filled) + C.RESET
            boss_tag = f"{C.RED+C.BLINK}★{C.RESET}" if e.data.get('is_boss') else " "
            lines.append(L(f"{C.RED}║{C.RESET}  {boss_tag}{col}{e.sym}{C.RESET} {C.WHITE}{e.data['nama'][:10]}{C.RESET}"))
            lines.append(L(f"{C.RED}║{C.RESET}   [{hp_bar}]{ec}{e.hp}/{e.data['hp']}{C.RESET}"))
        if len(alive) > 4:
            lines.append(L(f"{C.RED}║{C.RESET}  {C.GRAY}+{len(alive)-4} lainnya...{C.RESET}"))
    else:
        lines.append(L(f"{C.RED}║{C.RESET} {C.GREEN}✓ Lantai Aman!{C.RESET}"))

    lines.append(L(f"{C.RED}╚{'═'*22}╝{C.RESET}"))

    while len(lines) < MAP_H:
        lines.append('')
    return lines
