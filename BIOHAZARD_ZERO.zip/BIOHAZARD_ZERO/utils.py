#!/usr/bin/env python3
# utils.py — Warna & helper terminal
import os, sys, time, textwrap

class C:
    RED     = '\033[91m'
    GREEN   = '\033[92m'
    YELLOW  = '\033[93m'
    BLUE    = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN    = '\033[96m'
    WHITE   = '\033[97m'
    GRAY    = '\033[90m'
    BOLD    = '\033[1m'
    DIM     = '\033[2m'
    RESET   = '\033[0m'
    BLINK   = '\033[5m'
    BG_RED  = '\033[41m'
    BG_BLUE = '\033[44m'

def clear():
    os.system('clear')

def getch():
    """Baca satu karakter tanpa Enter (Linux/Termux)."""
    import tty, termios
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
        # handle arrow keys (ESC sequence)
        if ch == '\x1b':
            ch2 = sys.stdin.read(1)
            ch3 = sys.stdin.read(1)
            arrows = {'A': 'k', 'B': 'j', 'C': 'l', 'D': 'h'}
            return arrows.get(ch3, ch)
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

def slow_print(text, delay=0.018, color=''):
    if color: print(color, end='', flush=True)
    for ch in text:
        print(ch, end='', flush=True)
        time.sleep(delay)
    if color: print(C.RESET, end='', flush=True)
    print()

def wrap_print(text, width=60, color=''):
    for line in textwrap.wrap(text, width):
        slow_print(line, delay=0.010, color=color)

def press_any():
    print(f"\n{C.GRAY}[ Tekan tombol apa saja... ]{C.RESET}", end='', flush=True)
    getch()
    print()

def divider(ch='─', n=64, color=C.GRAY):
    print(color + ch*n + C.RESET)
