#!/usr/bin/env python3
# main.py — Entry point BIOHAZARD ZERO Roguelike Edition
"""
Jalankan di Termux:
  cd ~/biohazard_nethack
  python3 main.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from engine import Game

if __name__ == '__main__':
    try:
        g = Game()
        g.start()
    except KeyboardInterrupt:
        from utils import C
        print(f"\n\n{C.RED}Game dihentikan. Sampai jumpa, survivor!{C.RESET}\n")
        sys.exit(0)
