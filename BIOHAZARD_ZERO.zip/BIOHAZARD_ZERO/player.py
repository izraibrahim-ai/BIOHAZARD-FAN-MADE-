#!/usr/bin/env python3
# player.py — Kelas Player dengan stats RPG lengkap

import json, os
from utils import C
from data  import CLASSES, SKILLS

SAVE_FILE = os.path.expanduser('~/biohazard_nh_save.json')

class Player:
    def __init__(self, nama, kelas_id):
        cls = CLASSES[kelas_id]
        self.nama      = nama
        self.kelas_id  = kelas_id
        self.kelas     = cls['nama']
        self.icon      = cls['icon']

        # Stats dasar
        self.max_hp    = cls['base_hp']
        self.hp        = cls['base_hp']
        self.max_mp    = cls['mp']
        self.mp        = cls['mp']
        self.atk       = cls['base_atk']
        self.base_atk  = cls['base_atk']
        self.defense   = cls['base_def']
        self.spd       = cls['base_spd']

        # Progression
        self.xp        = 0
        self.level     = 1
        self.gold      = 20

        # Skills
        self.skills    = list(cls['skills'])

        # Equip
        self.weapon    = None   # {'nama':..., 'atk':...}
        self.armor     = None   # {'nama':..., 'def':...}
        self.amulet    = None   # {'nama':..., 'bonus':..., 'nilai':...}

        # Inventory (list of item dict)
        self.inventory = []
        self.inv_max   = 50     # 50 slot tas
        self.notes_bag = []    # slot khusus kertas (unlimited)

        # Status efek
        self.poisoned  = False
        self.bleeding  = False
        self.guarding  = False
        self.evading   = False

        # Posisi di map
        self.x = 0
        self.y = 0
        self.floor = 1

        # Log
        self.kills         = 0
        self.floors_cleared = 0
        self.bosses_killed  = []  # list floor boss yang sudah mati

    # ── Computed stats ────────────────────────────────────────
    @property
    def total_atk(self):
        base = self.atk
        if self.weapon:  base += self.weapon.get('atk', 0)
        if self.amulet and self.amulet.get('bonus') == 'atk':
            base += self.amulet['nilai']
        return base

    @property
    def total_def(self):
        base = self.defense
        if self.armor:   base += self.armor.get('def', 0)
        if self.amulet and self.amulet.get('bonus') == 'def':
            base += self.amulet['nilai']
        return base

    @property
    def total_max_hp(self):
        base = self.max_hp
        if self.amulet and self.amulet.get('bonus') == 'hp':
            base += self.amulet['nilai']
        return base

    # ── HP/MP bars ────────────────────────────────────────────
    def hp_bar(self, length=16):
        pct    = max(0, self.hp) / self.total_max_hp
        filled = int(pct * length)
        bar    = '█' * filled + '░' * (length - filled)
        color  = C.GREEN if pct > 0.6 else C.YELLOW if pct > 0.3 else C.RED
        return f"{color}[{bar}]{C.RESET} {self.hp}/{self.total_max_hp}"

    def mp_bar(self, length=10):
        if self.max_mp == 0:
            return f"{C.GRAY}[──────────]{C.RESET} --"
        pct    = max(0, self.mp) / self.max_mp
        filled = int(pct * length)
        bar    = '█' * filled + '░' * (length - filled)
        return f"{C.BLUE}[{bar}]{C.RESET} {self.mp}/{self.max_mp}"

    # ── Level up ──────────────────────────────────────────────
    def xp_needed(self):
        return int(self.level * 80 * (1.2 ** (self.level - 1)))

    def try_level_up(self):
        msgs = []
        while self.xp >= self.xp_needed():
            self.xp      -= self.xp_needed()
            self.level   += 1
            self.max_hp  += 15
            self.hp       = min(self.hp + 15, self.total_max_hp)
            self.atk     += 2
            self.defense += 1
            if self.max_mp > 0:
                self.max_mp += 5
                self.mp      = min(self.mp + 5, self.max_mp)
            msgs.append(f"⭐ LEVEL UP! → Lv{self.level}  HP+15  ATK+2  DEF+1")
        return msgs

    # ── Status tick ───────────────────────────────────────────
    def tick_status(self):
        msgs = []
        if self.poisoned:
            dmg = 3
            self.hp = max(0, self.hp - dmg)
            msgs.append(f"{C.MAGENTA}☠ Racun: -{dmg} HP{C.RESET}")
        if self.bleeding:
            dmg = 2
            self.hp = max(0, self.hp - dmg)
            msgs.append(f"{C.RED}🩸 Bleeding: -{dmg} HP{C.RESET}")
        return msgs

    # ── Inventory ─────────────────────────────────────────────
    def add_item(self, item):
        if len(self.inventory) >= self.inv_max:
            return False
        self.inventory.append(item)
        return True

    def remove_item(self, idx):
        if 0 <= idx < len(self.inventory):
            return self.inventory.pop(idx)
        return None

    # ── Save / Load ───────────────────────────────────────────
    def save(self):
        data = self.__dict__.copy()
        with open(SAVE_FILE, 'w') as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls):
        if not os.path.exists(SAVE_FILE):
            return None
        try:
            with open(SAVE_FILE) as f:
                data = json.load(f)
            p = cls.__new__(cls)
            p.__dict__.update(data)
            return p
        except:
            return None

    @staticmethod
    def delete_save():
        if os.path.exists(SAVE_FILE):
            os.remove(SAVE_FILE)
