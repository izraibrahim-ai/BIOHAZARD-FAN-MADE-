#!/usr/bin/env python3
# missions.py — Sistem misi per floor

from utils import C, clear, slow_print, press_any

# ══════════════════════════════════════════════════════════════
#  DATABASE MISI PER FLOOR
# ══════════════════════════════════════════════════════════════
# Setiap misi punya:
#   id       : string unik
#   floor    : di floor mana misi ini aktif
#   judul    : nama misi
#   briefing : cerita/konteks misi
#   tugas    : list langkah yang harus dilakukan (urutan)
#   tipe     : 'kill_boss' | 'reach_stairs' | 'kill_all' | 'survive' | 'collect'
#   reward_xp: bonus XP saat selesai

MISSIONS = [
    # ── FLOOR 1 ──────────────────────────────────────────────
    {
        'id': 'f1_escape',
        'floor': 1,
        'judul': 'Misi 1: Lolos dari Desa',
        'briefing': [
            "Kamu mendarat di Desa Pueblo.",
            "Desa ini sudah terinfeksi Plagas — penduduknya",
            "berubah menjadi Ganado yang agresif.",
            "",
            "Tujuanmu: temukan tangga menuju Gereja Desa",
            "dan lolos dari zona ini sebelum terjebak.",
            "",
            "Hati-hati — Ganado bisa menggunakan senjata.",
        ],
        'tugas': [
            "Jelajahi Desa Pueblo (Floor 1)",
            "Kalahkan atau hindari musuh di desa",
            "Temukan tangga turun [>] ke Gereja",
            "Turun ke Floor 2",
        ],
        'tipe': 'reach_stairs',
        'reward_xp': 50,
    },
    # ── FLOOR 2 ──────────────────────────────────────────────
    {
        'id': 'f2_gigante',
        'floor': 2,
        'judul': 'Misi 2: Jatuhkan El Gigante',
        'briefing': [
            "Gereja Desa dikuasai oleh El Gigante —",
            "manusia yang dimutasi Plagas hingga sebesar",
            "rumah. Satu hantamannya bisa mematikan.",
            "",
            "Taktik: El Gigante punya titik lemah di",
            "punggungnya. Serang Plagas yang muncul",
            "dari punggungnya untuk damage maksimal.",
            "",
            "Kalahkan El Gigante dan lanjutkan ke Kastil.",
        ],
        'tugas': [
            "Masuk ke Gereja Desa (Floor 2)",
            "Temukan El Gigante [X] di dalam gereja",
            "Kalahkan El Gigante — BOSS FIGHT",
            "Turun ke Floor 3 — Kastil Salazar",
        ],
        'tipe': 'kill_boss',
        'reward_xp': 120,
    },
    # ── FLOOR 3 ──────────────────────────────────────────────
    {
        'id': 'f3_castle',
        'floor': 3,
        'judul': 'Misi 3: Tembus Kastil Salazar',
        'briefing': [
            "Kastil Ramon Salazar — megah tapi berbahaya.",
            "Licker merayap di langit-langit, Crimson Head",
            "berlari lebih cepat dari zombie biasa.",
            "",
            "Salazar adalah pemimpin Los Illuminados.",
            "Ia mengendalikan segalanya dari kastil ini.",
            "",
            "Tembus kastil dan cari jalan ke lab bawah",
            "tempat eksperimen Plagas dilakukan.",
        ],
        'tugas': [
            "Masuki Kastil Salazar (Floor 3)",
            "Waspadai Licker [L] di langit-langit",
            "Waspadai Crimson Head [C] yang berlari cepat",
            "Temukan tangga ke Lab Bawah Kastil",
        ],
        'tipe': 'reach_stairs',
        'reward_xp': 80,
    },
    # ── FLOOR 4 ──────────────────────────────────────────────
    {
        'id': 'f4_mrx',
        'floor': 4,
        'judul': 'Misi 4: Hancurkan Tyrant T-00',
        'briefing': [
            "Lab bawah kastil menyimpan rahasia terbesar:",
            "Proyek TYRANT. Mr. X — Tyrant T-00 —",
            "adalah senjata biologis sempurna Umbrella.",
            "",
            "Mr. X tidak bisa dihentikan dengan pistol biasa.",
            "Gunakan senjata berat. Tembak berulang.",
            "Jika mantelnya lepas — LARI dan tembak terus.",
            "",
            "Data antivirus tersimpan di server lab ini.",
        ],
        'tugas': [
            "Masuki Lab Bawah Kastil (Floor 4)",
            "Temukan Mr. X — Tyrant T-00 [X]",
            "Kalahkan Mr. X — gunakan senjata berat!",
            "Ambil data dari server lab",
            "Turun ke Fasilitas Umbrella",
        ],
        'tipe': 'kill_boss',
        'reward_xp': 200,
    },
    # ── FLOOR 5 ──────────────────────────────────────────────
    {
        'id': 'f5_umbrella',
        'floor': 5,
        'judul': 'Misi 5: Infiltrasi Fasilitas Umbrella',
        'briefing': [
            "Fasilitas Umbrella — tempat bioweapon diciptakan.",
            "Hunter Alpha berpatroli di setiap koridor.",
            "Molded merayap dari ventilasi.",
            "",
            "Dr. Ashford meninggalkan pesan:",
            "Formula antivirus ada di NEST Core,",
            "server merah di pojok barat.",
            "",
            "Terobos fasilitas dan capai NEST Core.",
            "Ini misi paling berbahaya sejauh ini.",
        ],
        'tugas': [
            "Masuki Fasilitas Umbrella (Floor 5)",
            "Hindari atau kalahkan Hunter Alpha [H]",
            "Cari jalur menuju NEST Core Facility",
            "Turun ke NEST — lantai terakhir",
        ],
        'tipe': 'reach_stairs',
        'reward_xp': 150,
    },
    # ── FLOOR 6 ──────────────════════════════════════════════
    {
        'id': 'f6_nemesis',
        'floor': 6,
        'judul': 'Misi AKHIR: Hancurkan NEMESIS',
        'briefing': [
            "NEST Core Facility. Di sinilah segalanya bermula.",
            "Di sinilah semua harus berakhir.",
            "",
            "NEMESIS-T Type — senjata terakhir Umbrella.",
            "Lebih kuat dari Mr. X. Bisa bicara.",
            "Satu targetnya: S.T.A.R.S.",
            "",
            "Tidak ada pelarian. Tidak ada jalan pintas.",
            "Kalahkan NEMESIS, ambil formula antivirus,",
            "dan selamatkan dunia dari Umbrella Corporation.",
            "",
            "GOOD LUCK, SOLDIER.",
        ],
        'tugas': [
            "Masuki NEST Core Facility (Floor 6)",
            "Temukan NEMESIS-T Type [N]",
            "Kalahkan NEMESIS — FINAL BOSS",
            "Ambil formula antivirus dari server merah",
            "Selamatkan dunia dari Umbrella",
        ],
        'tipe': 'kill_boss',
        'reward_xp': 500,
    },
]

def get_mission(floor):
    """Ambil misi untuk floor tertentu."""
    for m in MISSIONS:
        if m['floor'] == floor:
            return m
    return None

def get_active_step(mission, player):
    """
    Tentukan langkah misi mana yang sedang aktif.
    Return index langkah (0-based) dan status selesai atau tidak.
    """
    if mission is None:
        return 0, False

    tipe  = mission['tipe']
    floor = mission['floor']

    bosses = getattr(player, 'bosses_killed', [])
    fl_clr = getattr(player, 'floors_cleared', 0)

    if tipe == 'kill_boss':
        if floor in bosses:
            return len(mission['tugas']) - 1, True
        elif player.floor > floor:
            return 2, False  # sudah lewat floor tapi boss belum (aneh)
        else:
            return min(1, len(mission['tugas']) - 1), False
    elif tipe == 'reach_stairs':
        if player.floor > floor:
            return len(mission['tugas']) - 1, True
        else:
            return 0, False

    return 0, False


# ══════════════════════════════════════════════════════════════
#  TAMPILKAN MISI — LAYAR PENUH
# ══════════════════════════════════════════════════════════════

def show_mission_screen(player):
    """Tampilkan layar misi lengkap semua floor."""
    clear()
    print(f"\n{C.RED}╔{'═'*56}╗{C.RESET}")
    print(f"{C.RED}║{C.RESET}  📋  {C.BOLD}DAFTAR MISI — BIOHAZARD ZERO{C.RESET}")
    print(f"{C.RED}╠{'═'*56}╣{C.RESET}")

    for m in MISSIONS:
        fl      = m['floor']
        step, done = get_active_step(m, player)
        is_cur  = (fl == player.floor)
        is_past = (fl < player.floor)
        is_fut  = (fl > player.floor)

        if done or is_past:
            status_icon = f"{C.GREEN}✔{C.RESET}"
            title_col   = C.GRAY
        elif is_cur:
            status_icon = f"{C.YELLOW}►{C.RESET}"
            title_col   = C.WHITE + C.BOLD
        else:
            status_icon = f"{C.GRAY}○{C.RESET}"
            title_col   = C.GRAY

        print(f"{C.RED}║{C.RESET} {status_icon} {title_col}{m['judul']}{C.RESET}")

        # Tampilkan tugas hanya untuk floor aktif
        if is_cur:
            for ti, tugas in enumerate(m['tugas']):
                if ti < step:
                    print(f"{C.RED}║{C.RESET}     {C.GREEN}✓{C.RESET} {C.GRAY}{tugas}{C.RESET}")
                elif ti == step:
                    print(f"{C.RED}║{C.RESET}     {C.YELLOW}►{C.RESET} {C.WHITE}{tugas}{C.RESET}")
                else:
                    print(f"{C.RED}║{C.RESET}     {C.GRAY}○ {tugas}{C.RESET}")
            print(f"{C.RED}║{C.RESET}")

    print(f"{C.RED}╠{'═'*56}╣{C.RESET}")

    # Ringkasan progress
    total_fl = 6
    done_fl  = len([m for m in MISSIONS
                    if get_active_step(m, player)[1] or m['floor'] < player.floor])
    pct = int(done_fl / total_fl * 100)
    bar = '█' * int(pct/5) + '░' * (20 - int(pct/5))
    print(f"{C.RED}║{C.RESET}  Progress: {C.GREEN}[{bar}]{C.RESET} {pct}%  ({done_fl}/{total_fl} zona)")
    print(f"{C.RED}║{C.RESET}  Floor saat ini: {C.CYAN}{player.floor}/6{C.RESET}"
          f"   Level: {C.YELLOW}Lv{player.level}{C.RESET}"
          f"   Kills: {C.RED}{player.kills}{C.RESET}")
    print(f"{C.RED}╠{'═'*56}╣{C.RESET}")
    print(f"{C.RED}║{C.RESET}  {C.GRAY}[ ENTER / q ] Kembali{C.RESET}")
    print(f"{C.RED}╚{'═'*56}╝{C.RESET}")

    from utils import getch
    while True:
        ch = getch()
        if ch in ('\r', '\n', 'q', 'Q', 'm', 'M'):
            break


def show_mission_briefing(player, floor):
    """Tampilkan briefing misi saat masuk floor baru."""
    m = get_mission(floor)
    if not m:
        return
    clear()
    print(f"\n{C.YELLOW}╔{'═'*54}╗{C.RESET}")
    print(f"{C.YELLOW}║{C.RESET}  📋  {C.BOLD}{m['judul']}{C.RESET}")
    print(f"{C.YELLOW}╠{'═'*54}╣{C.RESET}")
    print(f"{C.YELLOW}║{C.RESET}")
    for line in m['briefing']:
        if line == '':
            print(f"{C.YELLOW}║{C.RESET}")
        else:
            slow_print(f"  {line}", delay=0.018, color=C.WHITE)
    print(f"{C.YELLOW}║{C.RESET}")
    print(f"{C.YELLOW}╠{'═'*54}╣{C.RESET}")
    print(f"{C.YELLOW}║{C.RESET}  {C.CYAN}OBJEKTIF:{C.RESET}")
    for tugas in m['tugas']:
        print(f"{C.YELLOW}║{C.RESET}   {C.GRAY}○{C.RESET} {C.WHITE}{tugas}{C.RESET}")
    print(f"{C.YELLOW}║{C.RESET}")
    print(f"{C.YELLOW}╠{'═'*54}╣{C.RESET}")
    print(f"{C.YELLOW}║{C.RESET}  {C.GRAY}[ ENTER ] Mulai misi{C.RESET}")
    print(f"{C.YELLOW}╚{'═'*54}╝{C.RESET}")
    press_any()


def mission_hud(player):
    """
    Return 2 baris ringkas untuk HUD sidebar —
    misi aktif + langkah sekarang.
    """
    m = get_mission(player.floor)
    if not m:
        return ['', '']
    step, done = get_active_step(m, player)
    judul = m['judul'][:20]
    if done:
        tugas_str = f"{C.GREEN}✔ Selesai!{C.RESET}"
    else:
        tugas_str = m['tugas'][step][:20] if step < len(m['tugas']) else ''
    return [
        f" {C.YELLOW}📋 {judul}{C.RESET}",
        f"  {C.WHITE}► {tugas_str}{C.RESET}",
    ]
