#!/usr/bin/env python3
# save_load.py — Sistem simpan & muat checkpoint

import os, json, time
from utils import C, slow_print

SAVE_FILE = os.path.expanduser('~/biohazard_save.json')

def simpan_game(player):
    """Simpan state player ke checkpoint JSON."""
    try:
        data = player.__dict__.copy()
        wrapped = {
            'versi':     '2.0',
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'player':    data,
        }
        with open(SAVE_FILE, 'w') as f:
            json.dump(wrapped, f, indent=2)
        slow_print(f"  💾 Checkpoint disimpan! ({time.strftime('%H:%M:%S')})", color=C.GREEN)
        return True
    except Exception as e:
        slow_print(f"  ✘ Gagal menyimpan: {e}", color=C.RED)
        return False

def muat_game():
    """Muat checkpoint. Return wrapped dict atau None."""
    if not os.path.exists(SAVE_FILE):
        return None
    try:
        with open(SAVE_FILE) as f:
            data = json.load(f)
        # Support dua format: wrapped dict ATAU raw player dict
        if 'player' in data:
            return data
        else:
            return {'player': data, 'timestamp': '?'}
    except:
        return None

def hapus_save():
    if os.path.exists(SAVE_FILE):
        os.remove(SAVE_FILE)

def info_save():
    data = muat_game()
    if not data: return None
    p = data['player']
    nama  = p.get('nama', '?')
    level = p.get('level', 1)
    floor = p.get('floor', 1)
    ts    = data.get('timestamp', '?')
    return f"{nama} Lv{level} Floor {floor} — {ts}"
