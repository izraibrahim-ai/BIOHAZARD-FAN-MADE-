#!/usr/bin/env python3
# combat.py — Battle JRPG style dengan efek tembakan, bubble chat, info musuh

import random, time
from utils import C, clear, slow_print, press_any, divider, wrap_print
from inventory import item_menu_battle
from data  import SKILLS, SYM_COLOR

# ══════════════════════════════════════════════════
#  BUBBLE CHAT — dialog musuh & player
# ══════════════════════════════════════════════════
ENEMY_CHAT = {
    'Zombie':            ['*GROARRR*', '*mengerang*', 'Uuuurrghh...', '*merangkak ke arahmu*'],
    'Cerberus':          ['*GRRR!*', '*menggeram*', 'WOOF WOOF— *suara aneh*', '*menerkam!*'],
    'Ganado':            ['"¡Matalo!"', '"¡Coged al intruso!"', '"¡Allí está!"', '*berteriak dalam bahasa asing*'],
    'Licker':            ['*lidah menjulur*', '*mendesis*', '*merayap cepat*', 'SSSHHHHH...'],
    'Crimson Head':      ['*MENJERIT*', '*berlari sangat cepat*', 'GRAAAHHHH!!!', '*melompat ke arahmu*'],
    'Plagas Host':       ['*kepala terbuka*', '*parasit keluar dari leher*', 'SKREEEE!!!', '*berputar aneh*'],
    'Hunter Alpha':      ['*SKREEEEE!*', '*cakar terangkat*', '*siap memenggal*', 'RAAAHHH!'],
    'Molded':            ['*menetes-netes*', '*berubah bentuk*', 'glub glub...', '*mold menyembur*'],
    'Verdugo':           ['*ekor bergetar*', '*exoskeleton berderak*', '*mendesis keras*', 'KHHHHHH...'],
    'El Gigante':        ['*GEDEBUK LANTAI BERGETAR*', 'ROOOOAAAAR!!!', '*mengangkat batu besar*', 'BWAAHHH!!!'],
    'Mr. X — Tyrant T-00':['*langkah berat DOOM DOOM DOOM*', '*topi fedora jatuh*', '...', '*memandangmu dingin*'],
    'NEMESIS-T Type':    ['"S.T.A.R.S..."', '"S... T... A... R... S..."', '*tentakel menyambar*', 'STAAARS!!!'],
}

PLAYER_CHAT_FIGHT = [
    '"Rasakan ini!"',
    '"Mati kau!"',
    '"Tidak akan kubiarkan!"',
    '"Untuk Raccoon City!"',
    '"TAKE THIS!"',
    '"Pergi ke neraka!"',
]
PLAYER_CHAT_HIT = [
    '"Argh!"',
    '"Sialan!"',
    '"Ugh, masih berdiri juga?"',
    '"Kena!"',
    '"Tepat sasaran!"',
]
PLAYER_CHAT_HURT = [
    '"Aduh— masih bisa!"',
    '"Tahan... harus tahan!"',
    '"Belum selesai—"',
    '"ARGH!"',
    '"Sakit tapi aku belum kalah!"',
]
PLAYER_CHAT_LOW_HP = [
    '"Tidak... tidak boleh mati di sini..."',
    '"Bertahan... harus bertahan..."',
    '"Ashford masih menungguku..."',
    '"COME ON!!!"',
]

# Efek visual senjata
WEAPON_FX = {
    'pistol':   [
        "  {col}  BANG! ——→ 💥 {col2}[ -{dmg} ]{C.RESET}",
        "  {col}  *BLAM* ——→ 💥 {col2}[ -{dmg} ]{C.RESET}",
    ],
    'shotgun':  [
        "  {col}  BOOOM!!! ══════→ 💥💥 {col2}[ -{dmg} ]{C.RESET}",
        "  {col}  *KABOOM* ══════→ 💥💥 {col2}[ -{dmg} ]{C.RESET}",
    ],
    'knife':    [
        "  {col}  *SLASH* ——→ 🔪 {col2}[ -{dmg} ]{C.RESET}",
        "  {col}  *STAB!* ——→ 🔪 {col2}[ -{dmg} ]{C.RESET}",
    ],
    'melee':    [
        "  {col}  *CRUNCH!* ——→ 👊 {col2}[ -{dmg} ]{C.RESET}",
        "  {col}  *SMASH!* ——→ 💪 {col2}[ -{dmg} ]{C.RESET}",
    ],
    'launcher': [
        "  {col}  *FWOOOOSH* ══════→ 💣💥 {col2}[ -{dmg} ]{C.RESET}",
    ],
    'magnum':   [
        "  {col}  *KABLAM!!!* ══════→ 🔥💥 {col2}[ -{dmg} ]{C.RESET}",
    ],
    'rocket':   [
        "  {col}  *WHOOOOSH* ══════════→ 💥💥💥 {col2}[ -{dmg} ]{C.RESET}",
    ],
    'default':  [
        "  {col}  *HIT* ——→ {col2}[ -{dmg} ]{C.RESET}",
    ],
}

def _get_weapon_type(player):
    w = player.weapon
    if not w: return 'melee'
    n = w['nama'].lower()
    if 'rocket' in n:   return 'rocket'
    if 'magnum' in n or 'hawk' in n or 'butterfly' in n: return 'magnum'
    if 'launcher' in n: return 'launcher'
    if 'shotgun' in n or 'w-870' in n: return 'shotgun'
    if 'knife' in n or 'pisau' in n:   return 'knife'
    if 'pistol' in n or 'matilda' in n or 'sig' in n or 'p226' in n: return 'pistol'
    return 'melee'

def _weapon_fx_line(player, dmg, crit):
    wtype = _get_weapon_type(player)
    templates = WEAPON_FX.get(wtype, WEAPON_FX['default'])
    tpl = random.choice(templates)
    col  = C.YELLOW + C.BOLD if crit else C.WHITE
    col2 = C.RED + C.BOLD    if crit else C.RED
    return tpl.format(col=col, col2=col2, dmg=dmg, C=C)

def _bubble(speaker, text, color=C.WHITE, align='left'):
    """Render bubble chat sederhana."""
    text = str(text)
    pad  = len(text) + 4
    line_top = '╭' + '─' * pad + '╮'
    line_mid = '│  ' + text + '  │'
    line_bot = '╰' + '─' * pad + '╯'
    indent = '  ' if align == 'left' else ' ' * 20
    print(f"{indent}{color}{line_top}{C.RESET}")
    print(f"{indent}{color}{line_mid}{C.RESET}")
    print(f"{indent}{color}{line_bot}{C.RESET}")
    if align == 'left':
        print(f"  {color}◀ {speaker}{C.RESET}")
    else:
        print(f"{' '*20}{color}{speaker} ▶{C.RESET}")

# ══════════════════════════════════════════════════
#  MAIN BATTLE
# ══════════════════════════════════════════════════
def do_battle(player, enemy, dungeon):
    """Return: 'win' | 'dead' | 'fled'"""
    enemy_hp  = enemy.data['hp']
    enemy_max = enemy.data['hp']
    msgs      = []
    turn      = 0
    stun_next = False   # musuh terstun ronde berikutnya

    # ── Encounter intro ───────────────────────────────────────
    clear()
    is_boss = enemy.data.get('is_boss', False)
    _draw_encounter_intro(player, enemy, is_boss)
    press_any()

    while True:
        clear()
        _draw_battle(player, enemy, enemy_hp, enemy_max, msgs, turn)
        msgs = []

        # ── Player turn ───────────────────────────────────────
        sw_name = player.weapon['nama'] if player.weapon else 'Tangan kosong'
        print(f"\n  {C.YELLOW}┌─ AKSI {'─'*36}┐{C.RESET}")
        print(f"  {C.YELLOW}│{C.RESET}  {C.GREEN}[f]{C.RESET} Fight ({sw_name})"
              f"{'  ':>10}{C.GREEN}[s]{C.RESET} Skill"
              f"    {C.GREEN}[i]{C.RESET} Item   {C.YELLOW}│{C.RESET}")
        print(f"  {C.YELLOW}│{C.RESET}  {C.GREEN}[r]{C.RESET} Run"
              f"                              {C.GREEN}[z]{C.RESET} Status "
              f"{C.YELLOW}│{C.RESET}")
        print(f"  {C.YELLOW}└{'─'*44}┘{C.RESET}")

        from utils import getch
        ch = getch().lower()

        player.guarding = False
        player.evading  = False

        if ch == 'f':
            dmg, crit = _calc_dmg(player.total_atk, enemy.data.get('def', 0))
            enemy_hp -= dmg

            # Bubble player
            if player.hp / player.total_max_hp < 0.3:
                chat_p = random.choice(PLAYER_CHAT_LOW_HP)
            elif crit:
                chat_p = random.choice(PLAYER_CHAT_HIT)
            else:
                chat_p = random.choice(PLAYER_CHAT_FIGHT)

            msgs.append(f"")
            msgs.append(f"  {C.CYAN}@ {player.nama}:{C.RESET} {C.WHITE}{chat_p}{C.RESET}")
            fx = _weapon_fx_line(player, dmg, crit)
            msgs.append(fx)
            if crit:
                msgs.append(f"  {C.YELLOW + C.BOLD}  ★ CRITICAL HIT! ★{C.RESET}")

        elif ch == 's':
            result = _skill_menu(player, enemy, enemy_hp)
            if result is None:
                continue
            enemy_hp, skill_msgs = result
            msgs.extend(skill_msgs)
            if enemy.data.get('stunned_next'):
                stun_next = True
                enemy.data['stunned_next'] = False

        elif ch == 'i':
            result = item_menu_battle(player)
            if result == 'cancel':
                continue
            if result:
                msgs.extend(result)

        elif ch == 'r':
            chance = 0.4 + player.spd * 0.02
            if random.random() < chance:
                msgs.append(f"  {C.YELLOW}💨 Kamu berhasil kabur!{C.RESET}")
                clear()
                _draw_battle(player, enemy, enemy_hp, enemy_max, msgs, turn)
                press_any()
                return 'fled'
            else:
                msgs.append(f"  {C.RED}⚠ Gagal kabur!{C.RESET}")

        elif ch == 'z':
            _show_status(player)
            continue
        else:
            continue

        # Cek musuh mati
        if enemy_hp <= 0:
            msgs.append(f"")
            msgs.append(f"  {C.GREEN + C.BOLD}✔ {enemy.data['nama']} dikalahkan!{C.RESET}")
            xp   = enemy.data['xp']
            gold = random.randint(*enemy.data['gold'])
            player.xp   += xp
            player.gold += gold
            player.kills += 1
            msgs.append(f"  {C.YELLOW}+{xp} XP  |  +{gold} Gold{C.RESET}")
            lv_msgs = player.try_level_up()
            msgs.extend([f"  {C.YELLOW + C.BOLD}{m}{C.RESET}" for m in lv_msgs])

            drop_info = enemy.data.get('drop')
            if drop_info:
                sym, chance = drop_info
                if random.random() < chance:
                    from data import random_item
                    item = random_item(sym)
                    if item:
                        if player.add_item(item):
                            msgs.append(f"  {C.CYAN}💰 Drop: {item['nama']}{C.RESET}")
                        else:
                            msgs.append(f"  {C.GRAY}(Inventaris penuh){C.RESET}")

            clear()
            _draw_battle(player, enemy, 0, enemy_max, msgs, turn)
            press_any()
            return 'win'

        # ── Enemy turn ────────────────────────────────────────
        if stun_next or enemy.data.get('stunned'):
            enemy.data['stunned'] = False
            stun_next = False
            msgs.append(f"")
            msgs.append(f"  {C.YELLOW}💥 {enemy.data['nama']} terstun! Tidak bisa menyerang.{C.RESET}")
        elif player.evading and random.random() < 0.85:
            msgs.append(f"")
            msgs.append(f"  {C.GREEN}💨 Kamu berhasil menghindar dari serangan!{C.RESET}")
        else:
            e_dmg, e_crit = _calc_dmg(enemy.data['atk'], player.total_def)
            if player.guarding:
                e_dmg = e_dmg // 2

            # Status efek musuh
            status = enemy.data.get('status')
            if status and random.random() < 0.25:
                if status == 'poison' and not player.poisoned:
                    player.poisoned = True
                    msgs.append(f"  {C.MAGENTA}☠ Kamu diracuni!{C.RESET}")
                elif status == 'bleed' and not player.bleeding:
                    player.bleeding = True
                    msgs.append(f"  {C.RED}🩸 Kamu berdarah!{C.RESET}")

            player.hp = max(0, player.hp - e_dmg)

            # Bubble musuh
            e_chats = ENEMY_CHAT.get(enemy.data['nama'],
                                     ['*menyerang!*', '*menerjang!*'])
            e_chat  = random.choice(e_chats)
            msgs.append(f"")
            msgs.append(f"  {SYM_COLOR.get(enemy.sym,'')}{enemy.sym}{C.RESET}"
                        f" {C.RED}{enemy.data['nama']}:{C.RESET} {C.GRAY}{e_chat}{C.RESET}")

            arrow = '══════→' if e_crit else '──────→'
            guard_txt = f" {C.BLUE}[GUARD -50%]{C.RESET}" if player.guarding else ''
            crit_txt  = f" {C.YELLOW}CRITICAL!{C.RESET}" if e_crit else ''
            msgs.append(f"  {C.RED}  {arrow} 💢 [ -{e_dmg} HP ]{C.RESET}{crit_txt}{guard_txt}")

            # Player reaction
            pct = player.hp / player.total_max_hp
            if pct < 0.3:
                msgs.append(f"  {C.CYAN}@ {player.nama}:{C.RESET} {C.WHITE}{random.choice(PLAYER_CHAT_LOW_HP)}{C.RESET}")
            elif e_dmg > 20:
                msgs.append(f"  {C.CYAN}@ {player.nama}:{C.RESET} {C.WHITE}{random.choice(PLAYER_CHAT_HURT)}{C.RESET}")

        # Tick status
        tick = player.tick_status()
        msgs.extend(tick)

        if player.hp <= 0:
            msgs.append(f"\n  {C.RED + C.BOLD}💀 {player.nama} tewas...{C.RESET}")
            clear()
            _draw_battle(player, enemy, enemy_hp, enemy_max, msgs, turn)
            press_any()
            return 'dead'

        turn += 1


# ══════════════════════════════════════════════════
#  ENCOUNTER INTRO SCREEN
# ══════════════════════════════════════════════════
def _draw_encounter_intro(player, enemy, is_boss):
    esym  = SYM_COLOR.get(enemy.sym, C.WHITE)
    edata = enemy.data

    if is_boss:
        print(f"\n{C.RED}{'▓'*56}{C.RESET}")
        print(f"{C.RED + C.BOLD}{'':>10}!! BOSS ENCOUNTER !!{C.RESET}")
        print(f"{C.RED}{'▓'*56}{C.RESET}")
        print()
        # ASCII art boss name
        print(f"  {esym}{enemy.sym * 5}{C.RESET}  {C.RED + C.BOLD}{edata['nama'].upper()}{C.RESET}  {esym}{enemy.sym * 5}{C.RESET}")
        print()
    else:
        print(f"\n{C.RED}{'─'*56}{C.RESET}")
        print(f"  {C.RED}⚠  MUSUH MUNCUL!{C.RESET}")
        print(f"{C.RED}{'─'*56}{C.RESET}")
        print()
        print(f"  {esym}{enemy.sym}{C.RESET}  {C.WHITE + C.BOLD}{edata['nama']}{C.RESET}")
        print()

    # Info musuh
    print(f"  {C.GRAY}{'─'*40}{C.RESET}")
    print(f"  {C.WHITE}HP  :{C.RESET} {C.RED}{edata['hp']}{C.RESET}   "
          f"{C.WHITE}ATK :{C.RESET} {C.YELLOW}{edata['atk']}{C.RESET}   "
          f"{C.WHITE}DEF :{C.RESET} {C.BLUE}{edata['def']}{C.RESET}")
    status = edata.get('status')
    if status:
        sc = C.MAGENTA if status == 'poison' else C.RED
        print(f"  {C.WHITE}Efek:{C.RESET} {sc}{status.upper()}{C.RESET} — bisa mengenai kamu!")
    print(f"  {C.GRAY}{'─'*40}{C.RESET}")
    print()

    # Deskripsi musuh
    desc = edata.get('deskripsi', '')
    if desc:
        wrap_print(desc, width=52, color=C.YELLOW)
    print()

    # Bubble chat musuh saat muncul
    e_chats = ENEMY_CHAT.get(edata['nama'], ['*menyerang!*'])
    print(f"  {esym}{enemy.sym}{C.RESET} {C.GRAY}{random.choice(e_chats)}{C.RESET}")
    print()


# ══════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════
def _calc_dmg(atk, def_val):
    crit  = random.random() < 0.12
    base  = max(1, atk - def_val // 2)
    noise = random.randint(-base//4, base//4)
    dmg   = base + noise
    if crit: dmg = int(dmg * 1.8)
    return max(1, dmg), crit


def _skill_menu(player, enemy, enemy_hp):
    if not player.skills:
        print(f"\n  {C.GRAY}Tidak ada skill.{C.RESET}", end='')
        from utils import getch; getch()
        return None

    print(f"\n  {C.CYAN}━━ SKILL ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{C.RESET}")
    keys = 'abcdefghij'
    for i, sk_id in enumerate(player.skills):
        sk = SKILLS[sk_id]
        mp_cost = sk['mp']
        can   = player.mp >= mp_cost or mp_cost == 0
        color = C.WHITE if can else C.GRAY
        mp_str = f"MP:{mp_cost}" if mp_cost > 0 else "MP:─"
        print(f"  {C.YELLOW}[{keys[i]}]{C.RESET} {color}{sk['nama']:18}{C.RESET}"
              f"  {C.BLUE}{mp_str}{C.RESET}  {C.GRAY}{sk['deskripsi']}{C.RESET}")
    print(f"  {C.YELLOW}[q]{C.RESET} Batal")

    from utils import getch
    ch = getch().lower()
    if ch == 'q' or ch not in keys[:len(player.skills)]:
        return None

    idx   = keys.index(ch)
    sk_id = player.skills[idx]
    sk    = SKILLS[sk_id]
    msgs  = []

    if player.mp < sk['mp']:
        msgs.append(f"  {C.RED}MP tidak cukup! ({player.mp}/{sk['mp']}){C.RESET}")
        return enemy_hp, msgs

    player.mp -= sk['mp']
    msgs.append(f"  {C.CYAN}⚡ {player.nama} menggunakan {sk['nama']}!{C.RESET}")

    if sk['efek'] == 'damage':
        dmg, crit = _calc_dmg(int(player.total_atk * sk['nilai']), enemy.data.get('def', 0))
        if sk_id == 'aimed_shot' and random.random() < 0.5:
            crit = True
            dmg  = int(dmg * 1.8)
        enemy_hp -= dmg
        fx = _weapon_fx_line(player, dmg, crit)
        msgs.append(fx)
        if crit:
            msgs.append(f"  {C.YELLOW + C.BOLD}  ★ CRITICAL HIT! ★{C.RESET}")

    elif sk['efek'] == 'stun':
        enemy.data['stunned_next'] = True
        msgs.append(f"  {C.YELLOW}💥 Flash Grenade! Musuh akan terstun ronde ini!{C.RESET}")

    elif sk['efek'] == 'defend':
        player.guarding = True
        msgs.append(f"  {C.BLUE}🛡 Guard aktif! Damage berkurang 50%.{C.RESET}")

    elif sk['efek'] == 'evade':
        player.evading = True
        msgs.append(f"  {C.GREEN}💨 Tactical Evade! Dodge chance 85%.{C.RESET}")

    elif sk['efek'] == 'heal':
        heal = int(sk['nilai'])
        before = player.hp
        player.hp = min(player.total_max_hp, player.hp + heal)
        msgs.append(f"  {C.GREEN}💊 {sk['nama']}: HP +{player.hp - before} → {player.hp}/{player.total_max_hp}{C.RESET}")

    elif sk['efek'] == 'antidote':
        player.poisoned = False
        player.bleeding = False
        msgs.append(f"  {C.GREEN}💊 First Aid: Racun & bleeding disembuhkan!{C.RESET}")

    return enemy_hp, msgs


def _item_menu(player):
    usable = [(i, it) for i, it in enumerate(player.inventory)
              if it.get('efek') in ('heal', 'antidote', 'food', 'buff_atk')]

    if not usable:
        print(f"\n  {C.GRAY}Tidak ada item yang bisa dipakai.{C.RESET}", end='')
        from utils import getch; getch()
        return 'cancel'

    print(f"\n  {C.CYAN}━━ ITEM ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{C.RESET}")
    keys = 'abcdefghijklmnopqrstuvwxyz'
    for ki, (i, it) in enumerate(usable):
        efek = it.get('efek','')
        val  = it.get('nilai', 0)
        detail = ''
        if efek == 'heal':   detail = f"+{val if val!=999 else 'FULL'} HP"
        if efek == 'food':   detail = f"+{val} HP"
        if efek == 'antidote': detail = "sembuhkan racun/bleed"
        if efek == 'buff_atk': detail = f"ATK +{val}"
        print(f"  {C.YELLOW}[{keys[ki]}]{C.RESET} {C.WHITE}{it['nama']}{C.RESET}  {C.GRAY}{detail}{C.RESET}")
    print(f"  {C.YELLOW}[q]{C.RESET} Batal")

    from utils import getch
    ch = getch().lower()
    if ch == 'q' or ch not in keys[:len(usable)]:
        return 'cancel'

    idx    = keys.index(ch)
    inv_i, item = usable[idx]
    msgs   = []

    if item['efek'] == 'heal':
        val = item['nilai']
        if val == 999: val = player.total_max_hp
        before = player.hp
        player.hp = min(player.total_max_hp, player.hp + val)
        msgs.append(f"  {C.GREEN}💊 {item['nama']}: HP +{player.hp-before} → {player.hp}/{player.total_max_hp}{C.RESET}")
        player.remove_item(inv_i)
    elif item['efek'] == 'antidote':
        player.poisoned = False
        player.bleeding = False
        msgs.append(f"  {C.GREEN}💊 {item['nama']}: Racun & bleeding sembuh!{C.RESET}")
        player.remove_item(inv_i)
    elif item['efek'] == 'food':
        val = item['nilai']
        before = player.hp
        player.hp = min(player.total_max_hp, player.hp + val)
        msgs.append(f"  {C.GREEN}🍖 {item['nama']}: HP +{player.hp-before}{C.RESET}")
        player.remove_item(inv_i)
    elif item['efek'] == 'buff_atk':
        player.atk += item['nilai']
        msgs.append(f"  {C.YELLOW}💪 {item['nama']}: ATK permanen +{item['nilai']}!{C.RESET}")
        player.remove_item(inv_i)

    return msgs


def _show_status(player):
    clear()
    print(f"\n  {C.CYAN}━━ STATUS CHARACTER ━━━━━━━━━━━━━━━━━━━━━{C.RESET}")
    print(f"  {C.WHITE}{player.icon} {player.nama} — {player.kelas} Lv{player.level}{C.RESET}")
    print(f"  {'─'*42}")
    print(f"  HP   {player.hp_bar()}")
    print(f"  MP   {player.mp_bar()}")
    print(f"  ATK  {C.YELLOW}{player.total_atk}{C.RESET}   DEF {C.BLUE}{player.total_def}{C.RESET}   SPD {C.GREEN}{player.spd}{C.RESET}")
    print(f"  {'─'*42}")
    sw = player.weapon['nama'] if player.weapon else 'none'
    ar = player.armor['nama']  if player.armor  else 'none'
    print(f"  Weapon : {C.YELLOW}{sw}{C.RESET}")
    print(f"  Armor  : {C.BLUE}{ar}{C.RESET}")
    print(f"  {'─'*42}")
    s = []
    if player.poisoned: s.append(f"{C.MAGENTA}POISON{C.RESET}")
    if player.bleeding: s.append(f"{C.RED}BLEED{C.RESET}")
    print(f"  Status : {', '.join(s) if s else C.GREEN+'OK'+C.RESET}")
    press_any()


def _draw_battle(player, enemy, enemy_hp, enemy_max, msgs, turn):
    esym     = SYM_COLOR.get(enemy.sym, C.WHITE)
    is_boss  = enemy.data.get('is_boss', False)
    pct_e    = max(0, enemy_hp) / enemy_max
    pct_p    = player.hp / player.total_max_hp

    bar_len = 28
    bar_e_f = int(pct_e * bar_len)
    bar_p_f = int(pct_p * bar_len)
    ec      = C.GREEN if pct_e > 0.6 else C.YELLOW if pct_e > 0.3 else C.RED
    pc      = C.GREEN if pct_p > 0.6 else C.YELLOW if pct_p > 0.3 else C.RED
    boss_tag = f"  {C.RED+C.BLINK}[ ★ BOSS ★ ]{C.RESET}" if is_boss else ""

    # ── Header ───────────────────────────────────────────────────────────────
    border = '╔' + '═' * 54 + '╗'
    div    = '╠' + '═' * 54 + '╣'
    end    = '╚' + '═' * 54 + '╝'
    hcol   = C.RED if is_boss else C.GRAY
    print(f"\n{hcol}{border}{C.RESET}")
    print(f"{hcol}║{C.RESET}  {C.RED}⚔  PERTARUNGAN{C.RESET}{boss_tag}  "
          f"{C.GRAY}Turn {turn+1}  ·  Floor {player.floor}{C.RESET}")
    print(f"{hcol}{div}{C.RESET}")

    # ── Musuh ─────────────────────────────────────────────────────────────────
    print(f"\n  {esym}{enemy.sym * (3 if is_boss else 1)}{C.RESET}  "
          f"{C.RED+C.BOLD}{enemy.data['nama'].upper() if is_boss else enemy.data['nama']}{C.RESET}")
    bar_e_str = ec + '█' * bar_e_f + C.GRAY + '░' * (bar_len - bar_e_f) + C.RESET
    print(f"  {C.WHITE}HP{C.RESET} [{bar_e_str}] {ec}{max(0,enemy_hp)}/{enemy_max}{C.RESET}")

    estat = ''
    if enemy.data.get('stunned') or enemy.data.get('stunned_next'):
        estat += f"  {C.YELLOW}[STUN]{C.RESET}"
    status = enemy.data.get('status')
    if status:
        sc = C.MAGENTA if status == 'poison' else C.RED
        estat += f"  {sc}[{status.upper()}]{C.RESET}"
    if estat:
        print(f"  Status:{estat}")

    print(f"\n  {C.GRAY}{'─'*52}{C.RESET}")

    # ── Player ────────────────────────────────────────────────────────────────
    print(f"\n  {C.CYAN+C.BOLD}@ {player.nama}{C.RESET}  {C.GRAY}({player.kelas} Lv{player.level}){C.RESET}")
    bar_p_str = pc + '█' * bar_p_f + C.GRAY + '░' * (bar_len - bar_p_f) + C.RESET
    print(f"  {C.WHITE}HP{C.RESET} [{bar_p_str}] {pc}{player.hp}/{player.total_max_hp}{C.RESET}")
    print(f"  {player.mp_bar(20)}")

    pstat = ''
    if player.poisoned: pstat += f"  {C.MAGENTA}[POISON]{C.RESET}"
    if player.bleeding: pstat += f"  {C.RED}[BLEED]{C.RESET}"
    if player.guarding: pstat += f"  {C.BLUE}[GUARD]{C.RESET}"
    if player.evading:  pstat += f"  {C.GREEN}[EVADE]{C.RESET}"
    if pstat:
        print(f"  Status:{pstat}")

    sw = player.weapon['nama'] if player.weapon else 'Tangan Kosong'
    print(f"  {C.YELLOW}⚔ {sw}{C.RESET}  ATK:{C.YELLOW}{player.total_atk}{C.RESET}  DEF:{C.BLUE}{player.total_def}{C.RESET}")

    # ── Action log ────────────────────────────────────────────────────────────
    print(f"\n{C.GRAY}{'─'*56}{C.RESET}")
    for m in msgs[-8:]:
        print(m)
    for _ in range(max(0, 8 - len(msgs))):
        print()
    print(f"{hcol}{end}{C.RESET}")
