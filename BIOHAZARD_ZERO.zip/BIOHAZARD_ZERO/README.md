# BIOHAZARD ZERO — Roguelike Edition
NetHack-style ASCII dungeon crawler | Termux

## Install & Jalankan

```bash
pkg install python
cd ~/biohazard_nethack
python3 main.py
```

## Struktur File

```
biohazard_nethack/
├── main.py       ← Jalankan ini
├── engine.py     ← Game loop, title screen, floor management
├── dungeon.py    ← Generator peta procedural (rooms + koridor)
├── renderer.py   ← Render peta ASCII + sidebar + FOV
├── combat.py     ← Battle system JRPG style
├── inventory.py  ← Inventaris, equip, pakai item
├── player.py     ← Kelas Player + save/load
├── data.py       ← Semua konstanta, musuh, item, simbol
├── utils.py      ← Warna terminal, getch, helper
└── README.md
```

## Kontrol

| Tombol | Aksi |
|--------|------|
| `hjkl` / `←↑↓→` | Gerak (h=kiri j=bawah k=atas l=kanan) |
| `yubn` | Gerak diagonal |
| `g` | Ambil item di tile ini |
| `i` | Buka inventaris |
| `a` | Pakai item (shortcut) |
| `e` | Equip senjata/armor |
| `>` | Turun tangga (berdiri di `>`) |
| `<` | Naik tangga (berdiri di `<`) |
| `x` | Lihat sekitar |
| `S` | Simpan game |
| `Q` | Keluar |
| `?` | Help |

## Simbol Peta

| Simbol | Artinya |
|--------|---------|
| `@` | Kamu |
| `z` | Zombie |
| `L` | Licker |
| `H` | Hunter |
| `T` | Tyrant (Boss) |
| `B` | NEMESIS (Final Boss) |
| `$` | Gold |
| `!` | Potion |
| `)` | Senjata |
| `[` | Armor |
| `,` | Makanan |
| `"` | Amulet |
| `%` | Bangkai musuh |
| `>` | Tangga turun |
| `<` | Tangga naik |
| `^` | Jebakan |
| `+` | Pintu tertutup |

## Kelas

| Kelas | Keunggulan |
|-------|-----------|
| ⚔ Warrior | HP & ATK tinggi, skill Slash & Guard |
| 🏹 Ranger | SPD tinggi, critical tinggi, Aimed Shot |
| 💉 Medic | Skill heal & antidote dalam battle |

## Alur Game

- **6 Floor** procedurally generated
- Floor genap = **Boss Floor** (Neptune → Tyrant → NEMESIS)
- Kalahkan NEMESIS di Floor 6 untuk menang!
- **Permadeath** — mati = mulai ulang (save dihapus)
- FOV terbatas — tile gelap = belum pernah dilihat

Save file: `~/biohazard_nh_save.json`
