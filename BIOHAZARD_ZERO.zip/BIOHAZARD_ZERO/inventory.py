#!/usr/bin/env python3
# inventory.py — Inventory RE4 style: panel kiri = info, kanan = grid item

from utils import C, clear, getch, slow_print

# Navigasi: WASD / arrow-like, bukan huruf item
# Tombol aksi: ENTER/p=pakai, e=equip, d=buang, q=keluar, r=kertas, w=equip shortcut

EFEK_COL = {
    'weapon':   C.YELLOW,
    'armor':    C.BLUE,
    'heal':     C.GREEN,
    'antidote': C.GREEN,
    'food':     C.GREEN,
    'amulet':   C.CYAN,
    'buff_atk': C.RED,
}

ITEM_INFO = {
    'Green Herb':              {'ikon':'🌿','tipe':'Item Medis',  'asal':'Tanaman herbal liar tumbuh di sekitar Raccoon City dan wilayah terinfeksi.', 'guna':'Memulihkan 30 HP. Item survival paling dasar dan paling banyak ditemukan di lapangan.'},
    'Red+Green Herb':          {'ikon':'🌿','tipe':'Item Medis',  'asal':'Campuran Herb Hijau dan Herb Merah yang digabungkan secara manual.', 'guna':'Memulihkan 80 HP. Kombinasi paling umum yang dipakai agen lapangan.'},
    'Blue+Green Herb':         {'ikon':'🌿','tipe':'Item Medis',  'asal':'Campuran Herb Hijau dan Herb Biru. Herb Biru bersifat anti-toksin alami.', 'guna':'Memulihkan 40 HP sekaligus menyembuhkan racun dan bleeding.'},
    'Mixed Herb (G+R+B)':      {'ikon':'🌿','tipe':'Item Medis',  'asal':'Gabungan tiga jenis herb sekaligus. Sangat langka ditemukan.', 'guna':'Memulihkan 150 HP dan menyembuhkan semua status negatif sekaligus.'},
    'First Aid Spray':         {'ikon':'💉','tipe':'Item Medis',  'asal':'Diproduksi oleh Umbrella Medical Division untuk keperluan darurat lapangan.', 'guna':'Memulihkan HP penuh secara instan. Item paling langka dan paling berharga.'},
    'Antidote':                {'ikon':'💊','tipe':'Antidote',    'asal':'Produk farmasi standar Umbrella. Dibawa oleh semua personel di zona infeksi.', 'guna':'Menyembuhkan racun dan bleeding seketika. Wajib dibawa setiap misi.'},
    'Hemostatic Agent':        {'ikon':'💉','tipe':'Antidote',    'asal':'Kit medis lapangan khusus unit S.T.A.R.S. Dirancang untuk luka tempur.', 'guna':'Menghentikan bleeding secara instan. Tidak memulihkan HP.'},
    'Combat Knife':            {'ikon':'🔪','tipe':'Senjata',     'asal':'Pisau tempur standar militer Amerika Serikat. Dibawa semua prajurit.', 'guna':'DMG +7. Senjata cadangan saat amunisi habis. Efektif untuk Plagas yang keluar dari host.'},
    'Matilda (Pistol)':        {'ikon':'🔫','tipe':'Senjata',     'asal':'Pistol modifikasi custom milik Leon S. Kennedy. Dikustom untuk pertempuran jarak dekat.', 'guna':'DMG +16. Semi-otomatis dengan kapasitas tinggi. Senjata andalan utama Leon.'},
    'SIG Sauer P226':          {'ikon':'🔫','tipe':'Senjata',     'asal':'Pistol standar operasi khusus. Digunakan oleh unit BSAA dan S.T.A.R.S.', 'guna':'DMG +14. Akurasi sangat tinggi. Andalan agen BSAA di seluruh dunia.'},
    'W-870 Shotgun':           {'ikon':'🔫','tipe':'Senjata',     'asal':'Shotgun pump-action Winchester model 870. Senjata polisi dan militer AS.', 'guna':'DMG +35. Sangat efektif di jarak dekat. Bisa menghancurkan grup musuh sekaligus.'},
    'Grenade Launcher':        {'ikon':'💣','tipe':'Senjata',     'asal':'Peluncur granat militer. Dibawa oleh unit Jill Valentine di misi Raccoon City.', 'guna':'DMG +50. Memiliki radius ledak. Pilihan terbaik untuk melawan boss.'},
    'Lightning Hawk Magnum':   {'ikon':'🔫','tipe':'Senjata',     'asal':'Magnum Desert Eagle yang dimodifikasi khusus. Ditemukan di Kastil Salazar.', 'guna':'DMG +65. Satu tembakan bisa menghentikan Tyrant. Amunisi langka.'},
    'Broken Butterfly Mag.':   {'ikon':'🔫','tipe':'Senjata',     'asal':'Magnum antik dari koleksi pribadi Ramon Salazar. Dimodifikasi untuk pertempuran.', 'guna':'DMG +75. Power tertinggi di kelas pistol. Nama dari suara tembakannya.'},
    'Rocket Launcher':         {'ikon':'🚀','tipe':'Senjata',     'asal':'Peluncur roket anti-tank militer. Dibawa Leon untuk menghadapi NEMESIS.', 'guna':'DMG +120. Satu tembakan mengeliminasi musuh apapun tanpa terkecuali.'},
    'Tactical Vest':           {'ikon':'🦺','tipe':'Armor',       'asal':'Rompi taktis standar polisi dan agen keamanan. Ringan dan fleksibel.', 'guna':'DEF +7. Pelindung dasar yang ringan. Tidak mengganggu kecepatan gerak.'},
    'S.T.A.R.S. Uniform':      {'ikon':'🦺','tipe':'Armor',       'asal':'Seragam resmi unit elit S.T.A.R.S. Dibuat dari material khusus anti-infeksi.', 'guna':'DEF +10. Dirancang khusus untuk operasi di zona bio-hazard berbahaya.'},
    'Kevlar Suit':             {'ikon':'🦺','tipe':'Armor',       'asal':'Pakaian anti-peluru berbahan kevlar militer grade. Standar pasukan khusus.', 'guna':'DEF +14. Tahan terhadap senjata api kaliber standar dan serpihan ledakan.'},
    'BSAA Combat Armor':       {'ikon':'🛡','tipe':'Armor',       'asal':'Armor tempur resmi organisasi BSAA. Dipakai Chris Redfield di lapangan.', 'guna':'DEF +20. Standar operasi anti-bioterrorisme internasional.'},
    'Hazmat Suit':             {'ikon':'☣', 'tipe':'Armor',       'asal':'Setelan hazmat dari divisi penelitian Umbrella. Digunakan di lab berbahaya.', 'guna':'DEF +25. Tahan penuh terhadap bahan kimia, gas beracun, dan infeksi biologis.'},
    'Umbrella Prototype Suit': {'ikon':'☣', 'tipe':'Armor',       'asal':'Prototype armor eksperimental Umbrella. Belum dirilis ke produksi massal.', 'guna':'DEF +35. Teknologi armor paling canggih yang pernah dikembangkan Umbrella.'},
    'Gunpowder (ATK+)':        {'ikon':'💥','tipe':'Suplemen',    'asal':'Bubuk mesiu dari selongsong amunisi bekas. Diproses menjadi suplemen tempur.', 'guna':'ATK permanen +4. Dikonsumsi untuk meningkatkan kekuatan serangan secara permanen.'},
    'Field Ration':            {'ikon':'🍫','tipe':'Makanan',     'asal':'Ransum makanan militer standar. Dirancang untuk bertahan di kondisi ekstrem.', 'guna':'HP +25. Makanan darurat untuk agen di lapangan. Tidak butuh dimasak.'},
    'Protein Bar':             {'ikon':'🍫','tipe':'Makanan',     'asal':'Suplemen energi tinggi dari kit S.T.A.R.S. Diformulasikan khusus untuk agen.', 'guna':'HP +40. Memberikan energi instan saat kondisi sangat kritis.'},
    'Umbrella Keycard':        {'ikon':'🔑','tipe':'Amulet',      'asal':'Kartu akses fasilitas Umbrella. Mengandung chip RFID dengan enkripsi tinggi.', 'guna':'DEF +12 pasif. Chip di dalam kartu memancarkan medan pelindung lemah.'},
    'Plagas Parasite Shard':   {'ikon':'🦠','tipe':'Amulet',      'asal':'Pecahan parasit Plagas yang berhasil dikendalikan. Masih aktif secara biologis.', 'guna':'ATK +15 pasif. Energi dari parasit meningkatkan kekuatan serangan pemakainya.'},
    'Mold Fragment':           {'ikon':'🍄','tipe':'Amulet',      'asal':'Potongan Mold dari tubuh Ethan Winters. Mengandung kemampuan regenerasi.', 'guna':'MaxHP +40 pasif. Mold secara konstan meregenerasi sel-sel tubuh pemakai.'},
}

def _info(nama):
    return ITEM_INFO.get(nama, {
        'ikon':'📦','tipe':'Lainnya',
        'asal':'Asal usul tidak diketahui.',
        'guna':'Kegunaan tidak diketahui.'
    })

def _stat_str(item):
    efek = item.get('efek','')
    if efek == 'weapon':   return f"ATK +{item.get('atk',0)}"
    if efek == 'armor':    return f"DEF +{item.get('def',0)}"
    if efek == 'heal':
        v = item.get('nilai',0)
        return f"HP +{v if v!=999 else 'MAX'}"
    if efek == 'food':     return f"HP +{item.get('nilai',0)}"
    if efek == 'antidote': return "Sembuhkan status"
    if efek == 'amulet':   return f"{item.get('bonus','?')} +{item.get('nilai',0)}"
    if efek == 'buff_atk': return f"ATK +{item.get('nilai',0)} perm"
    return ''


# ══════════════════════════════════════════════════════════════
#  MAIN INVENTORY
# ══════════════════════════════════════════════════════════════

COLS     = 2   # kolom grid
ROWS     = 7   # baris grid (= 14 item per halaman)
PAGE     = COLS * ROWS
INFO_W   = 30  # lebar panel info kiri
GRID_COL = 24  # lebar satu kotak item

def show_inventory(player, mode='view'):
    cursor = 0
    page   = 0

    while True:
        inv      = player.inventory
        total    = len(inv)
        n_pages  = max(1, (total + PAGE - 1) // PAGE)
        start    = page * PAGE
        end      = min(start + PAGE, total)
        pg       = inv[start:end]

        # Clamp cursor
        cursor = max(0, min(cursor, len(pg) - 1)) if pg else 0

        clear()
        _draw(player, pg, cursor, start, page, n_pages)

        ch = getch()

        # ── Navigasi kursor ──────────────────────────────────
        if ch in ('k', '\x1b[A', 'w'):   # naik
            if cursor >= COLS: cursor -= COLS
            elif page > 0:     page -= 1; cursor = max(0, len(inv[((page)*PAGE):((page+1)*PAGE)])-1)
        elif ch in ('j', '\x1b[B', 's'): # turun
            if cursor + COLS < len(pg): cursor += COLS
            elif (page+1)*PAGE < total:  page += 1; cursor = 0
        elif ch in ('h', '\x1b[D', 'a'): # kiri
            if cursor % COLS > 0: cursor -= 1
        elif ch in ('l', '\x1b[C', 'd') and ch != 'd': # kanan (bukan d=drop)
            if cursor % COLS < COLS-1 and cursor+1 < len(pg): cursor += 1

        # ── Halaman ──────────────────────────────────────────
        elif ch == '<' and page > 0:     page -= 1; cursor = 0
        elif ch == '>' and end < total:  page += 1; cursor = 0

        # ── Keluar ───────────────────────────────────────────
        elif ch.lower() == 'q':
            return None

        # ── Aksi ─────────────────────────────────────────────
        elif ch in ('\r', '\n', 'p', ' '):   # pakai/pilih
            if pg:
                real_idx = start + cursor
                msg = _item_detail(player, real_idx, pg[cursor])
                if msg: return msg

        elif ch.lower() == 'e':              # equip shortcut
            msg = _equip_menu(player)
            if msg: return msg

        elif ch.lower() == 'd':              # buang
            if pg:
                real_idx = start + cursor
                msg = _drop_confirm(player, real_idx, pg[cursor])
                if msg: return msg

        elif ch.lower() == 'r':              # baca kertas
            msg = _read_notes_menu(player)
            if msg: return msg


# ══════════════════════════════════════════════════════════════
#  RENDER UTAMA
# ══════════════════════════════════════════════════════════════

def _draw(player, pg, cursor, start, page, n_pages):
    inv   = player.inventory
    total = len(inv)
    sc    = C.GREEN if total/player.inv_max < 0.7 else C.YELLOW if total/player.inv_max < 0.9 else C.RED
    TOTAL_W = INFO_W + 3 + GRID_COL * COLS + 1

    # ── Header ───────────────────────────────────────────────
    print(f"{C.RED}╔{'═'*TOTAL_W}╗{C.RESET}")
    print(f"{C.RED}║{C.RESET}  📦 {C.BOLD}ITEM BOX{C.RESET}"
          f"   {sc}{total}/{player.inv_max} slot{C.RESET}"
          f"   {C.YELLOW}💰 {player.gold}G{C.RESET}"
          f"   {C.CYAN}📄 {len(player.notes_bag)} catatan{C.RESET}")
    print(f"{C.RED}╠{'═'*INFO_W}╦{'═'*(GRID_COL*COLS+1)}╣{C.RESET}")

    # ── Ambil info item yang dikursor ─────────────────────────
    cur_item = pg[cursor] if pg else None
    info_lines = _build_info_panel(player, cur_item)
    grid_lines = _build_grid(pg, cursor)

    # ── Print info kiri + grid kanan berdampingan ─────────────
    max_rows = max(len(info_lines), len(grid_lines))
    for i in range(max_rows):
        il = info_lines[i] if i < len(info_lines) else ''
        gl = grid_lines[i] if i < len(grid_lines) else ''
        # Pad info line ke INFO_W karakter (tanpa ANSI)
        il_pad = _pad_ansi(il, INFO_W)
        print(f"{C.RED}║{C.RESET}{il_pad}{C.RED}║{C.RESET}{gl}")

    # ── Footer ────────────────────────────────────────────────
    print(f"{C.RED}╠{'═'*TOTAL_W}╣{C.RESET}")
    print(f"{C.RED}║{C.RESET}  {C.GRAY}Gerak: hjkl/wasd{C.RESET}"
          f"  {C.YELLOW}[Enter/p]{C.RESET}:pakai"
          f"  {C.YELLOW}[e]{C.RESET}:equip"
          f"  {C.YELLOW}[d]{C.RESET}:buang"
          f"  {C.YELLOW}[r]{C.RESET}:catatan"
          f"  {C.RED}[q]{C.RESET}:keluar"
          f"  {C.GRAY}hal {page+1}/{n_pages}{C.RESET}")
    print(f"{C.RED}╚{'═'*TOTAL_W}╝{C.RESET}")


def _build_info_panel(player, item):
    """Bangun baris-baris panel info kiri."""
    lines = []
    W = INFO_W - 2  # konten dalam border

    def L(s=''):
        lines.append(s)

    if item is None:
        L(f" {C.GRAY}{'─'*W}{C.RESET}")
        L(f" {C.GRAY}Tidak ada item{C.RESET}")
        for _ in range(ROWS*4 - 2):
            L()
        return lines

    info  = _info(item['nama'])
    efek  = item.get('efek','')
    col   = EFEK_COL.get(efek, C.WHITE)
    stat  = _stat_str(item)

    # Nama item
    L(f" {col}{'─'*W}{C.RESET}")
    L(f" {info['ikon']} {col}{C.BOLD}{item['nama'][:W-3]}{C.RESET}")
    L(f" {C.GRAY}{'─'*W}{C.RESET}")

    # Tipe + stat
    L(f" {C.YELLOW}Tipe  :{C.RESET} {C.WHITE}{info['tipe']}{C.RESET}")
    if stat:
        L(f" {C.YELLOW}Bonus :{C.RESET} {col}{stat}{C.RESET}")
    L()

    # Asal usul — wrap manual
    L(f" {C.YELLOW}Asal Usul:{C.RESET}")
    asal_words = info['asal'].split()
    line_buf = ''
    for w in asal_words:
        if len(line_buf) + len(w) + 1 > W - 1:
            L(f"  {C.GRAY}{line_buf}{C.RESET}")
            line_buf = w
        else:
            line_buf = (line_buf + ' ' + w).strip()
    if line_buf:
        L(f"  {C.GRAY}{line_buf}{C.RESET}")
    L()

    # Kegunaan — wrap manual
    L(f" {C.YELLOW}Kegunaan:{C.RESET}")
    guna_words = info['guna'].split()
    line_buf = ''
    for w in guna_words:
        if len(line_buf) + len(w) + 1 > W - 1:
            L(f"  {C.WHITE}{line_buf}{C.RESET}")
            line_buf = w
        else:
            line_buf = (line_buf + ' ' + w).strip()
    if line_buf:
        L(f"  {C.WHITE}{line_buf}{C.RESET}")
    L()

    # Equip saat ini
    L(f" {C.GRAY}{'─'*W}{C.RESET}")
    sw = player.weapon
    ar = player.armor
    L(f" {C.YELLOW}⚔{C.RESET} {C.WHITE}{(sw['nama'][:W-3] if sw else '(kosong)')}{C.RESET}")
    L(f" {C.BLUE}🛡{C.RESET} {C.WHITE}{(ar['nama'][:W-3] if ar else '(kosong)')}{C.RESET}")

    # Pad sisa
    target_rows = ROWS * 4 + 2
    while len(lines) < target_rows:
        L()

    return lines


def _build_grid(pg, cursor):
    """Bangun baris-baris grid item kanan."""
    lines = []

    for row in range(ROWS):
        li = row * COLS       # index kiri
        ri = row * COLS + 1   # index kanan

        l_item = pg[li] if li < len(pg) else None
        r_item = pg[ri] if ri < len(pg) else None

        l_sel  = (li == cursor)
        r_sel  = (ri == cursor)

        l_key  = str(li+1) if li < 9 else chr(ord('a') + li - 9)
        r_key  = str(ri+1) if ri < 9 else chr(ord('a') + ri - 9)

        # 4 baris per item row: top, icon+nama, asal+stat, bottom
        lines.append(_cell_top(l_item, l_sel, l_key) + _cell_top(r_item, r_sel, r_key))
        lines.append(_cell_mid(l_item, l_sel)        + _cell_mid(r_item, r_sel))
        lines.append(_cell_sub(l_item, l_sel)        + _cell_sub(r_item, r_sel))
        lines.append(_cell_bot(l_item, l_sel)        + _cell_bot(r_item, r_sel))

    return lines


def _cell_top(item, sel, key):
    W = GRID_COL
    if item:
        col   = EFEK_COL.get(item.get('efek',''), C.WHITE)
        sel_c = C.BOLD if sel else ''
        arrow = '►' if sel else ' '
        return f"{col}{sel_c}╭{arrow}[{key}]{'─'*(W-6)}╮{C.RESET}"
    return f"{C.GRAY}╭{'─'*(W-2)}╮{C.RESET}"

def _cell_mid(item, sel):
    W = GRID_COL
    if item:
        col   = EFEK_COL.get(item.get('efek',''), C.WHITE)
        sel_c = C.BOLD if sel else ''
        info  = _info(item['nama'])
        nama  = item['nama'][:W-6]
        return f"{col}{sel_c}│{C.RESET} {info['ikon']} {col}{sel_c}{nama:{W-6}}{C.RESET}{col}{sel_c}│{C.RESET}"
    return f"{C.GRAY}│{' '*(W-2)}│{C.RESET}"

def _cell_sub(item, sel):
    W = GRID_COL
    if item:
        col  = EFEK_COL.get(item.get('efek',''), C.WHITE)
        stat = _stat_str(item)
        asal = _info(item['nama'])['asal'][:W-4-len(stat)]
        return (f"{col}│{C.RESET} {C.GRAY}{asal:{W-4-len(stat)}}{C.RESET}"
                f"{col}{stat}{col}│{C.RESET}")
    return f"{C.GRAY}│{' '*(W-2)}│{C.RESET}"

def _cell_bot(item, sel):
    W = GRID_COL
    if item:
        col = EFEK_COL.get(item.get('efek',''), C.WHITE)
        return f"{col}╰{'─'*(W-2)}╯{C.RESET}"
    return f"{C.GRAY}╰{'─'*(W-2)}╯{C.RESET}"


# ── Helper: pad string yang mengandung ANSI ke lebar N char ──
def _pad_ansi(s, width):
    """Tambah spasi trailing supaya visible width = width."""
    import re
    visible = re.sub(r'\x1b\[[0-9;]*m', '', s)
    pad = width - len(visible)
    return s + ' ' * max(0, pad)


# ══════════════════════════════════════════════════════════════
#  DETAIL ITEM (setelah Enter)
# ══════════════════════════════════════════════════════════════

def _item_detail(player, idx, item):
    while True:
        clear()
        nama = item.get('nama','?')
        efek = item.get('efek','?')
        info = _info(nama)
        col  = EFEK_COL.get(efek, C.WHITE)

        print(f"\n{col}╔══════════════════════════════════════════════════╗{C.RESET}")
        print(f"{col}║{C.RESET}  {info['ikon']}  {C.BOLD}{C.WHITE}{nama}{C.RESET}")
        print(f"{col}╠══════════════════════════════════════════════════╣{C.RESET}")
        print(f"{col}║{C.RESET}  {C.YELLOW}Tipe     :{C.RESET} {info['tipe']}")
        print(f"{col}║{C.RESET}  {C.YELLOW}Asal     :{C.RESET} {C.GRAY}{info['asal'][:46]}{C.RESET}")
        if len(info['asal']) > 46:
            print(f"{col}║{C.RESET}           {C.GRAY}{info['asal'][46:92]}{C.RESET}")
        print(f"{col}║{C.RESET}  {C.YELLOW}Kegunaan :{C.RESET} {C.WHITE}{info['guna'][:46]}{C.RESET}")
        if len(info['guna']) > 46:
            print(f"{col}║{C.RESET}           {C.WHITE}{info['guna'][46:92]}{C.RESET}")
        print(f"{col}║{C.RESET}")

        stat = _stat_str(item)
        if stat:
            print(f"{col}║{C.RESET}  {col}{C.BOLD}{stat}{C.RESET}")
        print(f"{col}╠══════════════════════════════════════════════════╣{C.RESET}")

        actions = []
        if efek in ('heal','antidote','food','buff_atk'):
            print(f"{col}║{C.RESET}  {C.GREEN}[p]{C.RESET} Pakai sekarang")
            actions.append('p')
        if efek in ('weapon','armor','amulet'):
            print(f"{col}║{C.RESET}  {C.YELLOW}[e]{C.RESET} Equip")
            actions.append('e')
        print(f"{col}║{C.RESET}  {C.RED}[d]{C.RESET} Buang item ini")
        print(f"{col}║{C.RESET}  {C.GRAY}[q]{C.RESET} Kembali")
        print(f"{col}╚══════════════════════════════════════════════════╝{C.RESET}")

        ch = getch().lower()
        if ch == 'q': return None
        if ch == 'p' and 'p' in actions: return _use_item(player, idx, item)
        if ch == 'e' and 'e' in actions: return _equip_item(player, idx, item)
        if ch == 'd': return _drop_confirm(player, idx, item)


# ══════════════════════════════════════════════════════════════
#  EQUIP / DROP / NOTES
# ══════════════════════════════════════════════════════════════

def _equip_menu(player):
    eq = [(i,it) for i,it in enumerate(player.inventory)
          if it.get('efek') in ('weapon','armor','amulet')]
    if not eq: return None
    clear()
    print(f"{C.YELLOW}╔{'═'*46}╗{C.RESET}")
    print(f"{C.YELLOW}║{C.RESET}  ⚔ PILIH EQUIP")
    print(f"{C.YELLOW}╠{'═'*46}╣{C.RESET}")
    keys = '1234567890abcdefghijklmnopqrstuvwxyz'
    for ki,(i,it) in enumerate(eq):
        col = EFEK_COL.get(it.get('efek',''), C.WHITE)
        print(f"{C.YELLOW}║{C.RESET} {C.YELLOW}[{keys[ki]}]{C.RESET} {_info(it['nama'])['ikon']} "
              f"{col}{it['nama'][:28]:28}{C.RESET} {C.GRAY}{_stat_str(it)}{C.RESET}")
    print(f"{C.YELLOW}║{C.RESET}  {C.GRAY}[q] Batal")
    print(f"{C.YELLOW}╚{'═'*46}╝{C.RESET}")
    ch = getch().lower()
    if ch == 'q' or ch not in keys[:len(eq)]: return None
    real_idx, it = eq[keys.index(ch)]
    return _equip_item(player, real_idx, it)


def _drop_confirm(player, idx, item):
    clear()
    print(f"\n{C.RED}╔{'═'*44}╗{C.RESET}")
    print(f"{C.RED}║{C.RESET}  🗑 BUANG ITEM?")
    print(f"{C.RED}╠{'═'*44}╣{C.RESET}")
    print(f"{C.RED}║{C.RESET}  {C.WHITE}{item.get('nama','?')}{C.RESET}")
    print(f"{C.RED}║{C.RESET}  {C.RED}Item yang dibuang tidak bisa diambil lagi!{C.RESET}")
    print(f"{C.RED}╠{'═'*44}╣{C.RESET}")
    print(f"{C.RED}║{C.RESET}  {C.GREEN}[y]{C.RESET} Ya, buang    {C.GRAY}[q]{C.RESET} Batal")
    print(f"{C.RED}╚{'═'*44}╝{C.RESET}")
    ch = getch().lower()
    if ch == 'y':
        player.remove_item(idx)
        return f"🗑 {item.get('nama','?')} dibuang."
    return None


def _read_notes_menu(player):
    nb = player.notes_bag
    if not nb: return None
    clear()
    keys = '1234567890abcdefghijklmnopqrstuvwxyz'
    print(f"{C.CYAN}╔{'═'*50}╗{C.RESET}")
    print(f"{C.CYAN}║{C.RESET}  📄 CATATAN & KERTAS")
    print(f"{C.CYAN}╠{'═'*50}╣{C.RESET}")
    for ni, note in enumerate(nb):
        status = f"{C.GREEN}✓{C.RESET}" if note.get('read') else f"{C.YELLOW}●{C.RESET}"
        print(f"{C.CYAN}║{C.RESET} {C.YELLOW}[{keys[ni]}]{C.RESET} {status} 📄 {C.WHITE}{note['judul'][:40]}{C.RESET}")
    print(f"{C.CYAN}║{C.RESET}  {C.GRAY}[q] Kembali")
    print(f"{C.CYAN}╚{'═'*50}╝{C.RESET}")
    ch = getch().lower()
    if ch == 'q' or ch not in keys[:len(nb)]: return None
    note = nb[keys.index(ch)]
    _show_note(note)
    note['read'] = True
    return f"📄 Membaca: {note['judul']}"


def _show_note(note):
    clear()
    print(f"\n{C.YELLOW}{'═'*54}{C.RESET}")
    print(f"{C.YELLOW}  📄  {note.get('judul','Catatan')}{C.RESET}")
    print(f"{C.YELLOW}{'═'*54}{C.RESET}\n")
    for line in note.get('isi',[]):
        if line == '': print()
        else: slow_print(f"  {line}", delay=0.010, color=C.WHITE)
    print(f"\n{C.GRAY}{'─'*54}{C.RESET}")
    input(f"  {C.GRAY}[ ENTER untuk tutup ]{C.RESET}")


# ══════════════════════════════════════════════════════════════
#  USE & EQUIP LOGIC
# ══════════════════════════════════════════════════════════════

def _use_item(player, idx, item):
    efek = item.get('efek','')
    if efek == 'heal':
        val = item['nilai'] if item['nilai'] != 999 else player.total_max_hp
        before = player.hp
        player.hp = min(player.total_max_hp, player.hp + val)
        player.remove_item(idx)
        return f"💊 {item['nama']}: HP +{player.hp-before} → {player.hp}/{player.total_max_hp}"
    elif efek == 'antidote':
        player.poisoned = False; player.bleeding = False
        player.remove_item(idx)
        return f"💊 {item['nama']}: Racun & bleeding sembuh!"
    elif efek == 'food':
        before = player.hp
        player.hp = min(player.total_max_hp, player.hp + item['nilai'])
        player.remove_item(idx)
        return f"🍖 {item['nama']}: HP +{player.hp-before}"
    elif efek == 'buff_atk':
        player.atk += item['nilai']
        player.remove_item(idx)
        return f"💪 {item['nama']}: ATK permanen +{item['nilai']}"
    return None


def _equip_item(player, idx, item):
    efek = item.get('efek','')
    if efek == 'weapon':
        old = player.weapon; player.weapon = item; player.remove_item(idx)
        if old: player.add_item(old)
        return f"⚔ Equip {item['nama']} (ATK+{item.get('atk',0)})" + (f" — lepas {old['nama']}" if old else "")
    elif efek == 'armor':
        old = player.armor; player.armor = item; player.remove_item(idx)
        if old: player.add_item(old)
        return f"🛡 Equip {item['nama']} (DEF+{item.get('def',0)})" + (f" — lepas {old['nama']}" if old else "")
    elif efek == 'amulet':
        old = player.amulet; player.amulet = item; player.remove_item(idx)
        if old: player.add_item(old)
        return f"💍 Equip {item['nama']}" + (f" — lepas {old['nama']}" if old else "")
    return None


# ══════════════════════════════════════════════════════════════
#  BATTLE ITEM MENU
# ══════════════════════════════════════════════════════════════

def item_menu_battle(player):
    usable = [(i,it) for i,it in enumerate(player.inventory)
              if it.get('efek') in ('heal','antidote','food','buff_atk')]

    if not usable:
        clear()
        print(f"\n{C.RED}╔{'═'*48}╗{C.RESET}")
        print(f"{C.RED}║{C.RESET}  {C.YELLOW}⚠  TIDAK ADA ITEM YANG BISA DIPAKAI{C.RESET}")
        print(f"{C.RED}║{C.RESET}  {C.GRAY}Cari ! (potion/herb) di lantai atau ruangan{C.RESET}")
        print(f"{C.RED}╚{'═'*48}╝{C.RESET}")
        print(f"\n  {C.GRAY}[ Tekan sembarang tombol ]{C.RESET}")
        getch()
        return 'cancel'

    keys = '1234567890abcdefghijklmnopqrstuvwxyz'

    while True:
        clear()
        # Header
        print(f"\n{C.GREEN}╔{'═'*52}╗{C.RESET}")
        print(f"{C.GREEN}║{C.RESET}  💊  {C.BOLD}PILIH ITEM — PAKAI SAAT BATTLE{C.RESET}")
        print(f"{C.GREEN}╠{'═'*52}╣{C.RESET}")
        print(f"{C.GREEN}║{C.RESET}  {C.GRAY}HP saat ini: {C.RESET}"
              f"{C.RED if player.hp/player.total_max_hp < 0.3 else C.YELLOW if player.hp/player.total_max_hp < 0.6 else C.GREEN}"
              f"{player.hp}/{player.total_max_hp}{C.RESET}")
        print(f"{C.GREEN}╠{'═'*52}╣{C.RESET}")

        # Daftar item
        for ki,(i,it) in enumerate(usable):
            stat  = _stat_str(it)
            info  = _info(it['nama'])
            col   = EFEK_COL.get(it.get('efek',''), C.WHITE)
            # Highlight item heal kalau HP kritis
            urgent = (it.get('efek') in ('heal','food') and
                      player.hp / player.total_max_hp < 0.4)
            prefix = f"{C.YELLOW}★{C.RESET}" if urgent else " "
            print(f"{C.GREEN}║{C.RESET} {prefix}{C.YELLOW}[{keys[ki]}]{C.RESET} "
                  f"{info['ikon']} {col}{it['nama'][:28]:28}{C.RESET} "
                  f"{C.WHITE}{stat:16}{C.RESET}")
            print(f"{C.GREEN}║{C.RESET}      {C.GRAY}{info['guna'][:46]}{C.RESET}")
            print(f"{C.GREEN}║{C.RESET}")

        print(f"{C.GREEN}╠{'═'*52}╣{C.RESET}")
        print(f"{C.GREEN}║{C.RESET}  {C.GRAY}[q]{C.RESET} Batal — kembali ke battle")
        print(f"{C.GREEN}╚{'═'*52}╝{C.RESET}")
        print(f"\n  {C.YELLOW}Pilih item:{C.RESET} ", end='', flush=True)

        ch = getch().lower()

        if ch == 'q':
            return 'cancel'

        if ch not in keys[:len(usable)]:
            continue   # tombol salah, tampilkan ulang

        inv_i, item = usable[keys.index(ch)]
        msgs = []
        efek = item.get('efek','')

        if efek == 'heal':
            val = item['nilai'] if item['nilai'] != 999 else player.total_max_hp
            before = player.hp
            player.hp = min(player.total_max_hp, player.hp + val)
            msgs.append(f"  {C.GREEN}💊 {item['nama']}: HP +{player.hp-before} → {player.hp}/{player.total_max_hp}{C.RESET}")
            player.remove_item(inv_i)
        elif efek == 'antidote':
            player.poisoned = False
            player.bleeding = False
            msgs.append(f"  {C.GREEN}💊 {item['nama']}: Racun & bleeding sembuh!{C.RESET}")
            player.remove_item(inv_i)
        elif efek == 'food':
            before = player.hp
            player.hp = min(player.total_max_hp, player.hp + item['nilai'])
            msgs.append(f"  {C.GREEN}🍖 {item['nama']}: HP +{player.hp-before}{C.RESET}")
            player.remove_item(inv_i)
        elif efek == 'buff_atk':
            player.atk += item['nilai']
            msgs.append(f"  {C.YELLOW}💪 {item['nama']}: ATK +{item['nilai']} permanen{C.RESET}")
            player.remove_item(inv_i)

        return msgs
