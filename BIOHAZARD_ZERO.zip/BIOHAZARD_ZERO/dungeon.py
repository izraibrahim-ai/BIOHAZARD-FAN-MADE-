#!/usr/bin/env python3
# dungeon.py — Generator dungeon NetHack style

import random
from data import get_enemy_pool, random_item, random_gold, ITEM_TABLE
from notes import get_random_note

MAP_W  = 60
MAP_H  = 22

TILE_EMPTY    = ' '
TILE_FLOOR    = '.'   # lantai dalam ruangan
TILE_CORRIDOR = '.'   # koridor (sama, bisa dilewati)
TILE_WALL_H   = '─'
TILE_WALL_V   = '│'
TILE_CORNER   = '+'   # sudut ruangan (pakai + agar mudah dibedain)
TILE_DOOR_O   = '['   # pintu — tampil sebagai []
TILE_DOOR_S   = '['   # sama dengan DOOR_O
TILE_STAIRS   = '>'
TILE_STAIRS_U = '<'
TILE_TRAP     = '^'
TILE_CORPSE   = '%'
TILE_NOTE     = '?'   # kertas/catatan bisa dibaca


class Room:
    def __init__(self, x, y, w, h):
        self.x, self.y, self.w, self.h = x, y, w, h

    def center(self):
        return (self.x + self.w // 2, self.y + self.h // 2)

    def random_floor(self):
        x = random.randint(self.x + 1, self.x + self.w - 2)
        y = random.randint(self.y + 1, self.y + self.h - 2)
        return x, y

    def overlaps(self, other, margin=2):
        return not (
            self.x + self.w + margin < other.x or
            other.x + other.w + margin < self.x or
            self.y + self.h + margin < other.y or
            other.y + other.h + margin < self.y
        )

    def interior_tiles(self):
        pts = []
        for yy in range(self.y + 1, self.y + self.h - 1):
            for xx in range(self.x + 1, self.x + self.w - 1):
                pts.append((xx, yy))
        return pts


class Entity:
    def __init__(self, x, y, sym, data):
        self.x, self.y = x, y
        self.sym  = sym
        self.data = dict(data)
        self.hp   = data.get('hp', 1)
        self.alive = True


class Item:
    def __init__(self, x, y, sym, data):
        self.x, self.y = x, y
        self.sym  = sym
        self.data = dict(data)
        self.picked = False


class Note:
    def __init__(self, x, y, data):
        self.x, self.y = x, y
        self.data  = data   # {'judul': str, 'isi': [str,...]}
        self.read  = False


class Dungeon:
    def __init__(self, floor):
        self.floor      = floor
        self.map        = [[TILE_EMPTY] * MAP_W for _ in range(MAP_H)]
        self.rooms      = []
        self.entities   = []
        self.items      = []
        self.gold_piles = []
        self.notes      = []   # list of Note objects
        self.stairs_dn  = None
        self.stairs_up  = None
        self._generate(floor)
        self.spawn = self.rooms[0].center() if self.rooms else (1, 1)

    # ── Generator ─────────────────────────────────────────────
    def _generate(self, floor):
        self._place_rooms()
        self._carve_corridors()
        self._place_features(floor)

    def _place_rooms(self):
        for _ in range(100):
            w = random.randint(6, 13)
            h = random.randint(4, 8)
            x = random.randint(1, MAP_W - w - 2)
            y = random.randint(1, MAP_H - h - 2)
            r = Room(x, y, w, h)
            if any(r.overlaps(e) for e in self.rooms):
                continue
            self.rooms.append(r)
            self._draw_room(r)
            if len(self.rooms) >= 9:
                break

    def _draw_room(self, r):
        """Gambar ruangan: dinding di tepi, lantai di dalam."""
        for yy in range(r.y, r.y + r.h):
            for xx in range(r.x, r.x + r.w):
                if yy == r.y or yy == r.y + r.h - 1:
                    self.map[yy][xx] = TILE_WALL_H
                elif xx == r.x or xx == r.x + r.w - 1:
                    self.map[yy][xx] = TILE_WALL_V
                else:
                    self.map[yy][xx] = TILE_FLOOR
        # Sudut
        self.map[r.y][r.x]                   = '┌'
        self.map[r.y][r.x + r.w - 1]         = '┐'
        self.map[r.y + r.h - 1][r.x]         = '└'
        self.map[r.y + r.h - 1][r.x + r.w - 1] = '┘'

    def _carve_corridors(self):
        """Hubungkan semua ruangan dengan koridor lurus, lalu buka dinding."""
        for i in range(len(self.rooms) - 1):
            x1, y1 = self.rooms[i].center()
            x2, y2 = self.rooms[i + 1].center()
            # Koridor L-shape
            if random.random() < 0.5:
                self._dig_h(x1, x2, y1)
                self._dig_v(y1, y2, x2)
            else:
                self._dig_v(y1, y2, x1)
                self._dig_h(x1, x2, y2)
        # Setelah semua koridor digali, buka dinding yang tertembus
        self._open_walls()
        # Pastikan setiap ruangan punya minimal 1 pintu keluar
        self._ensure_room_exits()

    def _dig_h(self, x1, x2, y):
        """Gali koridor horizontal."""
        for x in range(min(x1, x2), max(x1, x2) + 1):
            if 0 < x < MAP_W - 1 and 0 < y < MAP_H - 1:
                t = self.map[y][x]
                if t == TILE_EMPTY:
                    self.map[y][x] = TILE_FLOOR
                elif t in (TILE_WALL_H, TILE_WALL_V, '┌', '┐', '└', '┘'):
                    self.map[y][x] = TILE_DOOR_O   # tembus dinding → pintu

    def _dig_v(self, y1, y2, x):
        """Gali koridor vertikal."""
        for y in range(min(y1, y2), max(y1, y2) + 1):
            if 0 < x < MAP_W - 1 and 0 < y < MAP_H - 1:
                t = self.map[y][x]
                if t == TILE_EMPTY:
                    self.map[y][x] = TILE_FLOOR
                elif t in (TILE_WALL_H, TILE_WALL_V, '┌', '┐', '└', '┘'):
                    self.map[y][x] = TILE_DOOR_O   # tembus dinding → pintu

    def _ensure_room_exits(self):
        """Pastikan setiap ruangan punya minimal 1 pintu keluar yang accessible."""
        floor_tiles = {TILE_FLOOR, TILE_DOOR_O, '·'}
        for room in self.rooms:
            has_exit = False
            # Cek apakah ada tile walkable di sisi ruangan
            for x in range(room.x, room.x + room.w):
                for y in [room.y, room.y + room.h - 1]:
                    # cek di luar dinding (atas/bawah)
                    if self.map[y][x] == TILE_DOOR_O:
                        has_exit = True
                    # cek ada floor/koridor di luar batas
                    outside_y = y - 1 if y == room.y else y + 1
                    if 0 < outside_y < MAP_H and self.map[outside_y][x] in floor_tiles:
                        self.map[y][x] = TILE_DOOR_O
                        has_exit = True
            for y in range(room.y, room.y + room.h):
                for x in [room.x, room.x + room.w - 1]:
                    if self.map[y][x] == TILE_DOOR_O:
                        has_exit = True
                    outside_x = x - 1 if x == room.x else x + 1
                    if 0 < outside_x < MAP_W and self.map[y][outside_x] in floor_tiles:
                        self.map[y][x] = TILE_DOOR_O
                        has_exit = True
            # Fallback: buka sisi tengah bawah ruangan ke koridor baru
            if not has_exit:
                cx, cy = room.center()
                # paksa buka ke bawah
                wy = room.y + room.h - 1
                self.map[wy][cx] = TILE_DOOR_O
                # gali koridor 2 tile ke bawah
                for extra in range(1, 3):
                    ny = wy + extra
                    if 0 < ny < MAP_H - 1:
                        if self.map[ny][cx] == TILE_EMPTY:
                            self.map[ny][cx] = TILE_FLOOR

    def _open_walls(self):
        """Scan seluruh map — dinding yang diapit floor di kedua sisi → pintu."""
        for y in range(1, MAP_H - 1):
            for x in range(1, MAP_W - 1):
                t = self.map[y][x]
                if t in (TILE_WALL_H, TILE_WALL_V, '┌', '┐', '└', '┘'):
                    n = self.map[y - 1][x]
                    s = self.map[y + 1][x]
                    w = self.map[y][x - 1]
                    e = self.map[y][x + 1]
                    floor_tiles = {TILE_FLOOR, TILE_DOOR_O}
                    if (n in floor_tiles and s in floor_tiles) or \
                       (w in floor_tiles and e in floor_tiles):
                        self.map[y][x] = TILE_DOOR_O

    # ── Features ──────────────────────────────────────────────
    def _place_features(self, floor):
        rooms = self.rooms[:]
        random.shuffle(rooms)

        # Tangga turun
        sx, sy = rooms[-1].center()
        self.map[sy][sx] = TILE_STAIRS
        self.stairs_dn = (sx, sy)

        # Tangga naik
        ux, uy = rooms[0].center()
        self.map[uy][ux] = TILE_STAIRS_U
        self.stairs_up = (ux, uy)

        # Monster
        pool = get_enemy_pool(floor)
        is_boss = (floor % 2 == 0)
        n_monsters = 1 if is_boss else random.randint(3, 5 + floor)

        placed = 0
        for r in rooms[1:]:
            if placed >= n_monsters:
                break
            if is_boss and placed == 0:
                ex, ey = r.center()
                e = Entity(ex, ey, pool[0]['sym'], pool[0])
                self.entities.append(e)
                placed += 1
            elif not is_boss:
                ex, ey = r.random_floor()
                m = random.choice(pool)
                e = Entity(ex, ey, m['sym'], dict(m))
                self.entities.append(e)
                placed += 1

        # Item — 5 health item per ruangan + item lain
        HEALTH_SYMS = ['!', '!', '!', ',', '!']  # mayoritas potion/herb
        OTHER_SYMS  = [')', '[', '"']

        for r in rooms:
            # 5 health/potion item per ruangan
            interior = r.interior_tiles()
            random.shuffle(interior)
            placed_health = 0
            for (ix, iy) in interior:
                if placed_health >= 5:
                    break
                if self.map[iy][ix] != TILE_FLOOR:
                    continue
                # Jangan tumpuk item
                if any(it.x == ix and it.y == iy for it in self.items):
                    continue
                sym = random.choice(HEALTH_SYMS)
                item_data = random_item(sym)
                if item_data:
                    self.items.append(Item(ix, iy, sym, item_data))
                    placed_health += 1

            # 1 item lain (senjata/armor) per ruangan dengan chance 50%
            if random.random() < 0.5 and len(interior) > placed_health:
                for (ix, iy) in interior[placed_health:]:
                    if self.map[iy][ix] != TILE_FLOOR:
                        continue
                    if any(it.x == ix and it.y == iy for it in self.items):
                        continue
                    sym = random.choice(OTHER_SYMS)
                    item_data = random_item(sym)
                    if item_data:
                        self.items.append(Item(ix, iy, sym, item_data))
                    break

        # Gold
        for r in rooms:
            if random.random() < 0.7:
                gx, gy = r.random_floor()
                self.gold_piles.append([gx, gy, random_gold(floor)])

        # Kertas/Catatan — 1 per ruangan
        for r in rooms:
            interior = r.interior_tiles()
            random.shuffle(interior)
            for (nx, ny) in interior:
                if self.map[ny][nx] != TILE_FLOOR:
                    continue
                if any(it.x == nx and it.y == ny for it in self.items):
                    continue
                note_data = get_random_note(floor)
                self.notes.append(Note(nx, ny, note_data))
                self.map[ny][nx] = TILE_NOTE
                break

        # Trap
        for _ in range(random.randint(1, 2 + floor // 2)):
            if len(rooms) > 1:
                r = random.choice(rooms[1:])
                tx, ty = r.random_floor()
                self.map[ty][tx] = TILE_TRAP

    # ── Queries ───────────────────────────────────────────────
    def tile_at(self, x, y):
        if 0 <= x < MAP_W and 0 <= y < MAP_H:
            return self.map[y][x]
        return TILE_EMPTY

    def is_walkable(self, x, y):
        """Tile yang bisa dilewati player dan musuh."""
        t = self.tile_at(x, y)
        return t in (
            TILE_FLOOR,    # '.'
            TILE_DOOR_O,   # '[' pintu
            TILE_STAIRS,   # '>'
            TILE_STAIRS_U, # '<'
            TILE_TRAP,     # '^'
            TILE_CORPSE,   # '%' — mayat bisa dilewati
            TILE_NOTE,     # '?' — kertas bisa dilewati
            '·',
        )

    def entity_at(self, x, y):
        for e in self.entities:
            if e.alive and e.x == x and e.y == y:
                return e
        return None

    def item_at(self, x, y):
        for i in self.items:
            if not i.picked and i.x == x and i.y == y:
                return i
        return None

    def gold_at(self, x, y):
        for g in self.gold_piles:
            if g[0] == x and g[1] == y and g[2] > 0:
                return g
        return None

    def note_at(self, x, y):
        for n in self.notes:
            if n.x == x and n.y == y:
                return n
        return None

    def open_door(self, x, y):
        if self.map[y][x] in (TILE_WALL_H, TILE_WALL_V, '┌', '┐', '└', '┘'):
            self.map[y][x] = TILE_DOOR_O
            return True
        return False
