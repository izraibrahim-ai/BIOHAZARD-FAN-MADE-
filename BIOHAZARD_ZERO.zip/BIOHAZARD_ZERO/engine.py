#!/usr/bin/env python3
# engine.py — Game loop utama NetHack style

import sys, random, time
from utils     import C, clear, slow_print, wrap_print, press_any, divider, getch
from data      import TRAP_MSG, SYM_COLOR, CUTSCENES, get_floor_info
from notes     import get_random_note
from missions  import show_mission_screen, show_mission_briefing, get_mission, mission_hud
from dungeon   import Dungeon, MAP_W, MAP_H, TILE_STAIRS, TILE_STAIRS_U, TILE_TRAP, TILE_DOOR_O, TILE_DOOR_S, TILE_CORPSE, TILE_FLOOR, TILE_NOTE
from player    import Player
from combat    import do_battle
from renderer  import render
from inventory import show_inventory
from enemy_ai  import update_enemies

MAX_FLOOR = 6

class Game:
    def __init__(self):
        self.player   = None
        self.dungeon  = None
        self.seen     = set()   # fog of war
        self.messages = []
        self.running  = True

    # ── Pesan ─────────────────────────────────────────────────
    def msg(self, text):
        self.messages.append(text)
        if len(self.messages) > 50:
            self.messages.pop(0)

    # ── Render ────────────────────────────────────────────────
    def draw(self):
        clear()
        render(self.dungeon, self.player, self.messages, self.seen)

    # ── Cutscene ─────────────────────────────────────────────
    def play_cutscene(self, key):
        cs = CUTSCENES.get(key)
        if not cs:
            return
        clear()
        warna = cs.get('warna', C.WHITE)
        print(f"\n{warna}{'═'*60}{C.RESET}")
        print(f"{warna}{C.BOLD}  {cs['judul']}{C.RESET}")
        print(f"{warna}{'═'*60}{C.RESET}\n")
        for line in cs['teks']:
            if line == '':
                print()
            else:
                slow_print(f"  {line}", delay=0.022, color=C.WHITE)
        print(f"\n{C.GRAY}{'─'*60}{C.RESET}")
        press_any()

    # ── Pindah floor ─────────────────────────────────────────
    def load_floor(self, floor, from_above=False, show_cutscene=True):
        self.dungeon  = Dungeon(floor)
        self.seen     = set()
        self.player.floor = floor

        if from_above:
            self.player.x, self.player.y = self.dungeon.stairs_dn
        else:
            self.player.x, self.player.y = self.dungeon.spawn

        if show_cutscene:
            cs_key = f'enter_{floor}'
            if cs_key in CUTSCENES:
                self.play_cutscene(cs_key)

        info = get_floor_info(floor)
        self.msg(f"{C.CYAN}─ {info['simbol']} {info['nama']}: {info['flavor']}{C.RESET}")
        # Tampilkan briefing misi untuk floor ini
        if show_cutscene:
            show_mission_briefing(self.player, floor)

        # Patch atribut baru untuk kompatibilitas save lama
        if not hasattr(self.player,'bosses_killed'): self.player.bosses_killed = []
        if not hasattr(self.player,'notes_bag'):     self.player.notes_bag = []
        if not hasattr(self.player,'inv_max') or self.player.inv_max < 50: self.player.inv_max = 50

        if floor % 2 == 0:
            if floor in self.player.bosses_killed:
                self.msg(f"{C.GREEN}✔ Boss floor ini sudah kamu kalahkan sebelumnya.{C.RESET}")
                # Hapus entitas boss dari dungeon — sudah mati
                self.dungeon.entities = [en for en in self.dungeon.entities if not en.data.get('is_boss')]
            else:
                self.msg(f"{C.RED + C.BLINK}⚠  BOSS FLOOR! Bersiaplah!{C.RESET}")

    # ── Gerak player ─────────────────────────────────────────
    def move_player(self, dx, dy):
        p  = self.player
        nx = p.x + dx
        ny = p.y + dy
        d  = self.dungeon

        if not (0 <= nx < MAP_W and 0 <= ny < MAP_H):
            return

        tile = d.tile_at(nx, ny)

        # Pintu terbuka langsung lewat (sudah included di is_walkable)
        # Tidak ada pintu tertutup lagi — semua pintu terbuka otomatis saat generate

        if not d.is_walkable(nx, ny):
            return

        # Cek musuh di tile tujuan
        entity = d.entity_at(nx, ny)
        if entity and entity.alive:
            self._do_combat(entity)
            return

        # Gerak
        p.x, p.y = nx, ny

        # Tick status (poison/bleed)
        ticks = p.tick_status()
        for t in ticks: self.msg(t)

        # Cek mati dari status efek
        if p.hp <= 0:
            self.running = False
            return

        # Cek item otomatis
        gold = d.gold_at(nx, ny)
        if gold:
            amt = gold[2]
            p.gold += amt
            gold[2] = 0
            self.msg(f"{C.YELLOW}$ Mengambil {amt} gold.{C.RESET}")

        # Cek trap
        if tile == TILE_TRAP:
            self._trigger_trap(nx, ny)

        # Penanda tangga — tampilkan tujuan saat player menginjak tangga
        if tile == TILE_STAIRS:
            next_floor = p.floor + 1
            if next_floor <= MAX_FLOOR:
                ninfo    = get_floor_info(next_floor)
                is_boss  = (next_floor % 2 == 0)
                boss_tag = f" {C.RED}[⚠ BOSS!]{C.RESET}" if is_boss and next_floor not in getattr(p,'bosses_killed',[]) else ""
                done_tag = f" {C.GREEN}[Boss sudah mati]{C.RESET}" if is_boss and next_floor in getattr(p,'bosses_killed',[]) else ""
                self.msg(f"{C.WHITE}▼ Tangga turun → Floor {next_floor}: {ninfo['simbol']} {ninfo['nama']}{boss_tag}{done_tag}{C.RESET}")
                self.msg(f"{C.GRAY}  Tekan [>] untuk turun{C.RESET}")
            else:
                self.msg(f"{C.RED}▼ Tangga turun → Ini lantai terakhir!{C.RESET}")

        elif tile == TILE_STAIRS_U:
            prev_floor = p.floor - 1
            if prev_floor >= 1:
                pinfo = get_floor_info(prev_floor)
                self.msg(f"{C.WHITE}▲ Tangga naik → Floor {prev_floor}: {pinfo['simbol']} {pinfo['nama']}{C.RESET}")
                self.msg(f"{C.GRAY}  Tekan [<] untuk naik{C.RESET}")
            else:
                self.msg(f"{C.GRAY}▲ Tangga naik → Sudah di lantai pertama{C.RESET}")

        # Cek kertas/catatan
        if tile == '?':
            note = self.dungeon.note_at(self.player.x, self.player.y)
            if note and not note.read:
                self._baca_note(note)
                # Simpan ke notes_bag player
                if not hasattr(self.player, 'notes_bag'):
                    self.player.notes_bag = []
                note_entry = dict(note.data)
                note_entry['read'] = True
                self.player.notes_bag.append(note_entry)
            if not self.running:
                return

        # Update AI musuh setiap player bergerak
        update_enemies(self.dungeon, self.player, self.msg)

        # Cek kalau musuh sudah nginjek posisi player setelah gerak
        if self.running:
            entity = self.dungeon.entity_at(self.player.x, self.player.y)
            if entity and entity.alive:
                self._do_combat(entity)

    # ── Combat ────────────────────────────────────────────────
    def _do_combat(self, entity):
        result = do_battle(self.player, entity, self.dungeon)
        if result == 'win':
            entity.alive = False
            self.dungeon.map[entity.y][entity.x] = '%'
            # Boss win cutscene
            if entity.data.get('is_boss'):
                # Catat boss floor ini sudah mati — tidak respawn
                if not hasattr(self.player,'bosses_killed'): self.player.bosses_killed = []
                if self.player.floor not in self.player.bosses_killed:
                    self.player.bosses_killed.append(self.player.floor)
                cs_key = f'boss_win_{self.player.floor}'
                if cs_key in CUTSCENES:
                    self.play_cutscene(cs_key)
                # TRIGGER ENDING jika boss terakhir (floor 6) sudah kalah
                if self.player.floor >= MAX_FLOOR:
                    self.player.hp = max(1, self.player.hp)  # pastikan tidak mati
                    self.running = False  # keluar dari run loop → ke _ending()
                    return
        elif result == 'dead':
            self._handle_death()
        elif result == 'fled':
            self.msg(f"{C.YELLOW}Kamu berhasil kabur!{C.RESET}")

    # ── Trap ─────────────────────────────────────────────────
    def _trigger_trap(self, x, y):
        p   = self.player
        msg = random.choice(TRAP_MSG)
        dmg = random.randint(5, 10 + self.player.floor * 2)
        dmg = max(1, dmg - p.total_def // 2)
        p.hp = max(0, p.hp - dmg)
        self.msg(f"{C.RED}^  {msg} -{dmg} HP{C.RESET}")
        # Trap hilang setelah dipicu
        self.dungeon.map[y][x] = '·'
        if p.hp <= 0:
            self.msg(f"{C.RED}💀 Kamu tewas karena jebakan!{C.RESET}")
            self.running = False

    # ── Ambil item (g) ────────────────────────────────────────
    def pick_up(self):
        p  = self.player
        d  = self.dungeon
        it = d.item_at(p.x, p.y)
        if not it:
            self.msg("Tidak ada item di sini.")
            return
        if p.add_item(it.data):
            it.picked = True
            col = SYM_COLOR.get(it.sym, C.WHITE)
            self.msg(f"{col}{it.sym}{C.RESET} Mengambil: {it.data['nama']}")
        else:
            self.msg(f"{C.RED}Inventaris penuh! ({p.inv_max} slot){C.RESET}")

    # ── Stairs ───────────────────────────────────────────────
    def use_stairs(self):
        p  = self.player
        d  = self.dungeon
        tx = d.tile_at(p.x, p.y)

        if tx == '>':  # turun
            if p.floor >= MAX_FLOOR:
                self.msg(f"{C.RED}Ini lantai terbawah. Selesaikan misi di sini!{C.RESET}")
                return
            next_floor = p.floor + 1
            next_info  = get_floor_info(next_floor)
            is_boss    = (next_floor % 2 == 0)
            boss_tag   = f" {C.RED}[⚠ BOSS FLOOR!]{C.RESET}" if is_boss else ''
            already    = next_floor in getattr(p,'bosses_killed',[])
            if is_boss and already:
                boss_tag = f" {C.GREEN}[Boss sudah mati]{C.RESET}"
            self.msg(f"{C.WHITE}▼ Turun ke Floor {next_floor}: {next_info['simbol']} {next_info['nama']}{boss_tag}{C.RESET}")
            p.floor += 1
            p.floors_cleared += 1
            p.mp = min(p.max_mp, p.mp + p.max_mp // 2)
            self.load_floor(p.floor, show_cutscene=True)

        elif tx == '<':  # naik
            if p.floor <= 1:
                self.msg(f"{C.GRAY}Kamu sudah di lantai paling atas.{C.RESET}")
                return
            prev_floor = p.floor - 1
            prev_info  = get_floor_info(prev_floor)
            self.msg(f"{C.WHITE}▲ Naik ke Floor {prev_floor}: {prev_info['simbol']} {prev_info['nama']}{C.RESET}")
            p.floor -= 1
            self.load_floor(p.floor, from_above=True, show_cutscene=False)
        else:
            self.msg(f"{C.GRAY}Tidak ada tangga di sini. Cari tanda > atau <{C.RESET}")

    # ── Look / inspect ────────────────────────────────────────
    def look_around(self):
        p = self.player
        d = self.dungeon
        things = []
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                nx, ny = p.x+dx, p.y+dy
                e = d.entity_at(nx, ny)
                if e:
                    things.append(f"  {SYM_COLOR.get(e.sym,'')}{e.sym}{C.RESET} "
                                  f"{e.data['nama']} HP:{e.hp}/{e.data['hp']}")
                it = d.item_at(nx, ny)
                if it:
                    things.append(f"  {SYM_COLOR.get(it.sym,'')}{it.sym}{C.RESET} "
                                  f"{it.data['nama']}")
                g = d.gold_at(nx, ny)
                if g:
                    things.append(f"  {C.YELLOW}${C.RESET} {g[2]} gold")

        if things:
            self.msg(f"Di sekitarmu:")
            for t in things: self.msg(t)
        else:
            self.msg("Tidak ada yang menarik di sekitarmu.")

    # ── Help ─────────────────────────────────────────────────
    def show_help(self):
        clear()
        print(f"""
  {C.CYAN}══ KONTROL ══════════════════════════════════════{C.RESET}
  {C.YELLOW}hjkl{C.RESET} atau {C.YELLOW}←↑↓→{C.RESET}  Gerak (h=kiri, j=bawah, k=atas, l=kanan)
  {C.YELLOW}yubn{C.RESET}              Gerak diagonal (y=kiri-atas, u=kanan-atas, dst)
  {C.YELLOW}g{C.RESET}                 Ambil item di tile ini
  {C.YELLOW}i{C.RESET}                 Buka inventaris (lihat & pakai)
  {C.YELLOW}a{C.RESET}                 Pakai item (shortcut)
  {C.YELLOW}e{C.RESET}                 Equip senjata/armor dari inventaris
  {C.YELLOW}>{C.RESET} / {C.YELLOW}<{C.RESET}            Turun / naik tangga (berdiri di tanda > atau <)
  {C.YELLOW}x{C.RESET}                 Lihat sekitar (look)
  {C.YELLOW}S{C.RESET}                 Simpan game
  {C.YELLOW}Q{C.RESET}                 Keluar game
  {C.YELLOW}?{C.RESET}                 Tampilkan help ini

  {C.CYAN}══ SIMBOL PETA ═══════════════════════════════════{C.RESET}
  {C.CYAN}@{C.RESET} Player         {C.GREEN}z{C.RESET} Zombie         {C.MAGENTA}L{C.RESET} Licker
  {C.YELLOW}${C.RESET} Gold           {C.MAGENTA}!{C.RESET} Potion         {C.CYAN}?{C.RESET} Scroll
  {C.YELLOW}){C.RESET} Senjata        {C.BLUE}[{C.RESET} Armor          {C.GREEN},{C.RESET} Makanan
  {C.YELLOW}"{C.RESET} Amulet         {C.RED}%{C.RESET} Bangkai         {C.WHITE}>{C.RESET} Tangga turun
  {C.WHITE}<{C.RESET} Tangga naik    {C.RED}^{C.RESET} Jebakan        {C.YELLOW}+{C.RESET} Pintu tertutup
  {C.YELLOW}/{C.RESET} Pintu terbuka  {C.GRAY}·{C.RESET} Lantai

  {C.CYAN}══ COMBAT ════════════════════════════════════════{C.RESET}
  Jalan ke arah musuh untuk menyerang.
  Menu battle: {C.YELLOW}f{C.RESET}=Fight  {C.YELLOW}s{C.RESET}=Skill  {C.YELLOW}i{C.RESET}=Item  {C.YELLOW}r{C.RESET}=Run

  {C.CYAN}══ TUJUAN ════════════════════════════════════════{C.RESET}
  Capai NEST (Floor 6), kalahkan NEMESIS, selamatkan Dr. Ashford!
""")
        press_any()

    # ── Main loop ─────────────────────────────────────────────
    def run(self):
        while self.running:
            self.draw()
            ch = getch()
            self._handle_input(ch)

            # Cek HP
            if self.player.hp <= 0:
                self._handle_death()

        self._ending()

    def _handle_input(self, ch):
        p = self.player
        # Gerak
        moves = {
            'h': (-1, 0), 'l': (1, 0), 'k': (0,-1), 'j': (0, 1),
            'y': (-1,-1), 'u': (1,-1), 'b': (-1, 1), 'n': (1, 1),
        }
        if ch in moves:
            self.move_player(*moves[ch])
            return

        if ch == 'g':
            self.pick_up()
        elif ch == '>':
            use_tile = self.dungeon.tile_at(self.player.x, self.player.y)
            if use_tile == '>':
                self.use_stairs()
            else:
                self.msg("Tidak ada tangga turun di sini.")
        elif ch == '<':
            use_tile = self.dungeon.tile_at(self.player.x, self.player.y)
            if use_tile == '<':
                self.use_stairs()
            else:
                self.msg("Tidak ada tangga naik di sini.")
        elif ch in ('i', 'I'):
            msg = show_inventory(self.player, mode='view')
            if msg: self.msg(msg)
        elif ch in ('a', 'A'):
            msg = show_inventory(self.player, mode='use')
            if msg: self.msg(msg)
        elif ch in ('e', 'E'):
            msg = show_inventory(self.player, mode='equip')
            if msg: self.msg(msg)
        elif ch == 'x':
            self.look_around()
        elif ch in ('S',):
            self._save_with_popup()
        elif ch in ('Q', 'q'):
            print(f"\n{C.YELLOW}Simpan & keluar game? [y=ya / n=lanjut]{C.RESET}", end='', flush=True)
            c2 = getch()
            if c2 == 'y':
                self._save_with_popup()
                self.running = False
                sys.exit(0)
            else:
                self.msg(f"{C.GREEN}Lanjut main!{C.RESET}")
        elif ch == '?':
            self.show_help()
        elif ch in ('m', 'M'):
            show_mission_screen(self.player)
        # Ignore unknown keys

    # ── Baca catatan/kertas ──────────────────────────────────
    def _baca_note(self, note):
        clear()
        judul = note.data.get('judul', 'Catatan Tidak Dikenal')
        isi   = note.data.get('isi', [])

        print(f"\n{C.YELLOW}╔{'═'*54}╗{C.RESET}")
        print(f"{C.YELLOW}║{C.RESET}  {C.YELLOW+C.BOLD}📄  CATATAN DITEMUKAN!{C.RESET}")
        print(f"{C.YELLOW}║{C.RESET}  {C.WHITE+C.BOLD}{judul}{C.RESET}")
        print(f"{C.YELLOW}╠{'═'*54}╣{C.RESET}\n")
        for line in isi:
            if line == '':
                print()
            else:
                slow_print(f"  {line}", delay=0.012, color=C.WHITE)
        print(f"\n{C.YELLOW}╚{'═'*54}╝{C.RESET}")

        note.read = True
        # Simpan ke notes_bag player supaya bisa dibaca ulang dari inventaris
        note_dict = {'judul': judul, 'isi': isi, 'read': True}
        if not hasattr(self.player, 'notes_bag'):
            self.player.notes_bag = []
        # Hindari duplikat
        if not any(n.get('judul') == judul for n in self.player.notes_bag):
            self.player.notes_bag.append(note_dict)

        # Hapus tile ? dari map
        self.dungeon.map[note.y][note.x] = '.'
        self.player.xp += 15
        slow_print(f"\n  {C.CYAN}+15 XP  |  📄 Catatan disimpan ke tas!{C.RESET}")
        input(f"\n  {C.GRAY}[ Tekan ENTER untuk lanjut... ]{C.RESET}")

    # ── Save dengan popup konfirmasi ─────────────────────────
    def _save_with_popup(self):
        import time, os
        p = self.player

        # Lakukan save
        p.save()

        # Catat waktu save di player object supaya bisa ditampilkan di HUD
        p._last_save_time = time.strftime('%H:%M:%S')

        # Tampilkan popup konfirmasi jelas
        clear()
        ts   = time.strftime('%Y-%m-%d %H:%M:%S')
        save_path = os.path.expanduser('~/biohazard_nh_save.json')

        print(f"""
{C.GREEN}  ╔══════════════════════════════════════════════╗
  ║                                              ║
  ║   💾  CHECKPOINT DISIMPAN!                   ║
  ║                                              ║
  ╠══════════════════════════════════════════════╣
  ║                                              ║{C.RESET}
  {C.GREEN}║{C.RESET}   Nama    : {C.YELLOW}{p.nama:<30}{C.GREEN}  ║{C.RESET}
  {C.GREEN}║{C.RESET}   Kelas   : {C.WHITE}{p.kelas:<30}{C.GREEN}  ║{C.RESET}
  {C.GREEN}║{C.RESET}   Level   : {C.YELLOW}Lv{p.level:<29}{C.GREEN}  ║{C.RESET}
  {C.GREEN}║{C.RESET}   Floor   : {C.CYAN}{p.floor}/6{' ':<28}{C.GREEN}  ║{C.RESET}
  {C.GREEN}║{C.RESET}   HP      : {C.WHITE}{p.hp}/{p.total_max_hp:<27}{C.GREEN}  ║{C.RESET}
  {C.GREEN}║{C.RESET}   Gold    : {C.YELLOW}{p.gold:<30}{C.GREEN}  ║{C.RESET}
  {C.GREEN}║{C.RESET}   Waktu   : {C.GRAY}{ts:<30}{C.GREEN}  ║{C.RESET}
  {C.GREEN}║{C.RESET}   File    : {C.GRAY}{save_path[:30]:<30}{C.GREEN}  ║{C.RESET}
{C.GREEN}  ║                                              ║
  ╠══════════════════════════════════════════════╣
  ║                                              ║
  ║   ✔  Kalau mati, kamu akan dimuat dari       ║
  ║      checkpoint ini dengan HP sebagian.      ║
  ║                                              ║
  ╚══════════════════════════════════════════════╝{C.RESET}
""")
        time.sleep(0.3)
        input(f"  {C.GRAY}[ Tekan ENTER untuk lanjut... ]{C.RESET}")
        self.msg(f"{C.GREEN}💾 Checkpoint disimpan — {ts}{C.RESET}")

    # ── Handle Death — Checkpoint System ────────────────────
    def _handle_death(self):
        """Kalau ada save → load checkpoint. Kalau tidak → game over."""
        import time
        clear()
        print(f"""
{C.RED}  ╔══════════════════════════════════════╗
  ║         💀  KAMU TEWAS...           ║
  ╚══════════════════════════════════════╝{C.RESET}
""")
        time.sleep(1.0)
        # Coba load save dari player.load() (file ~/biohazard_nh_save.json)
        saved = Player.load()
        if saved:
            slow_print(f"  📂 Checkpoint ditemukan!", color=C.YELLOW)
            slow_print(f"  {saved.nama} Lv{saved.level} Floor {saved.floor}", color=C.WHITE)
            slow_print(f"  Memuat checkpoint...", color=C.GRAY)
            time.sleep(1.2)
            import time as _t
            self.player   = saved
            self.player._last_save_time = getattr(saved, '_last_save_time', None)
            self.dungeon  = None
            self.seen     = set()
            self.messages = []
            self.running  = True
            self.load_floor(self.player.floor, show_cutscene=False)
            # Pulihkan 1/3 HP saat respawn dari checkpoint
            self.player.hp = max(self.player.total_max_hp // 3, 20)
            self.msg(f"{C.YELLOW}⚠  Dimuat dari checkpoint! HP dipulihkan sebagian.{C.RESET}")
        else:
            slow_print("  Tidak ada checkpoint tersimpan.", color=C.RED)
            slow_print("  Tip: Tekan [S] untuk simpan checkpoint kapan saja!", color=C.GRAY)
            time.sleep(2.0)
            self.running = False

    # ── Ending ───────────────────────────────────────────────
    def _ending(self):
        p = self.player
        clear()
        bosses = getattr(p, 'bosses_killed', [])
        if p.hp <= 0 and MAX_FLOOR not in bosses:
            # Game over
            print(f"""
{C.RED}
  ██╗   ██╗ ██████╗ ██╗   ██╗    ██████╗ ██╗███████╗██████╗
  ╚██╗ ██╔╝██╔═══██╗██║   ██║    ██╔══██╗██║██╔════╝██╔══██╗
   ╚████╔╝ ██║   ██║██║   ██║    ██║  ██║██║█████╗  ██║  ██║
    ╚██╔╝  ██║   ██║██║   ██║    ██║  ██║██║██╔══╝  ██║  ██║
     ██║   ╚██████╔╝╚██████╔╝    ██████╔╝██║███████╗██████╔╝
     ╚═╝    ╚═════╝  ╚═════╝     ╚═════╝ ╚═╝╚══════╝╚═════╝
{C.RESET}""")
            slow_print(f"  {p.nama} tewas di {p.floor}.", color=C.RED)
            slow_print("  Raccoon City tidak bisa diselamatkan.", color=C.GRAY)
            slow_print("  Umbrella menang... untuk saat ini.", color=C.GRAY)
        else:
            # Menang
            print(f"""
{C.YELLOW}
  ███████╗███╗   ██╗██████╗ ██╗███╗   ██╗ ██████╗ ██╗
  ██╔════╝████╗  ██║██╔══██╗██║████╗  ██║██╔════╝ ██║
  █████╗  ██╔██╗ ██║██║  ██║██║██╔██╗ ██║██║  ███╗██║
  ██╔══╝  ██║╚██╗██║██║  ██║██║██║╚██╗██║██║   ██║╚═╝
  ███████╗██║ ╚████║██████╔╝██║██║ ╚████║╚██████╔╝██╗
  ╚══════╝╚═╝  ╚═══╝╚═════╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝
{C.RESET}""")
            slow_print(f"  NEMESIS dikalahkan. NEST dihancurkan.", color=C.GREEN)
            slow_print(f"  Dr. Ashford selamat. Data Umbrella ada di tangan dunia.", color=C.GREEN)
            slow_print(f"  Raccoon City bisa diselamatkan.", color=C.YELLOW)
            slow_print(f"  Tapi Umbrella... belum benar-benar mati.", color=C.GRAY)

        print(f"""
  {C.CYAN}── STATISTIK ───────────────────────────────────{C.RESET}
  Nama    : {p.nama} ({p.kelas})
  Level   : {p.level}
  Floor   : {p.floor}/{MAX_FLOOR}
  Kills   : {p.kills}
  Gold    : {p.gold}
  {C.CYAN}────────────────────────────────────────────────{C.RESET}
""")
        Player.delete_save()
        press_any()

    # ── Entry point ──────────────────────────────────────────
    def start(self):
        self._loading_screen()
        self._title_screen()

    def _loading_screen(self):
        """Loading screen dengan animasi + lisensi sebelum lobby."""
        import time
        clear()

        # ── LISENSI ───────────────────────────────────────────
        print(f"""
{C.RED}  ╔══════════════════════════════════════════════════════════╗
  ║                                                          ║
  ║          BIOHAZARD ZERO — ROGUELIKE EDITION              ║
  ║                   Text-Based RPG                         ║
  ║                                                          ║
  ╠══════════════════════════════════════════════════════════╣
  ║                                                          ║
  ║  © Capcom Co., Ltd.                                      ║
  ║  Resident Evil® adalah trademark terdaftar Capcom.       ║
  ║  Game ini adalah fan-made non-commercial project.        ║
  ║  Tidak berafiliasi dengan Capcom secara resmi.           ║
  ║                                                          ║
  ╠══════════════════════════════════════════════════════════╣
  ║                                                          ║
  ║  Engine   : Python 3 · Termux / Linux Terminal           ║
  ║  Gameplay : NetHack-style Roguelike                      ║
  ║  Versi    : 2.0                                          ║
  ║                                                          ║
  ╚══════════════════════════════════════════════════════════╝{C.RESET}
""")
        time.sleep(1.5)
        input(f"  {C.GRAY}[ Tekan ENTER untuk lanjut... ]{C.RESET}")

        # ── LOADING SCREEN ────────────────────────────────────
        clear()
        umbrella_logo = f"""
{C.RED}                    ░░░░░░░░░░░
                  ░░░░░░░░░░░░░░░
                ░░░░░  ░░░░░  ░░░░░
               ░░░░░    ░░░    ░░░░░
              ░░░░░░░░░░░░░░░░░░░░░░░
              ░░░░░░░░░░░░░░░░░░░░░░░
               ░░░░░░░░░░░░░░░░░░░░░
                ░░░░░  ░░░░░  ░░░░░
                  ░░░░░░░░░░░░░░░
                    ░░░░░░░░░░░{C.RESET}"""

        print(umbrella_logo)
        print(f"\n  {C.RED + C.BOLD}      UMBRELLA CORPORATION{C.RESET}")
        print(f"  {C.GRAY}      Obedience Breeds Discipline{C.RESET}")
        print(f"  {C.GRAY}      Discipline Breeds Unity{C.RESET}")
        print(f"  {C.GRAY}      Unity Breeds Power{C.RESET}")
        print(f"  {C.GRAY}      Power is Life{C.RESET}\n")

        # Loading bar animasi
        import sys
        stages = [
            ("Menginisiasi sistem...",          C.GRAY),
            ("Memuat data bioweapon...",         C.YELLOW),
            ("Mengaktifkan protokol T-Virus...", C.RED),
            ("Membuka pintu NEST...",            C.RED),
            ("SISTEM SIAP.",                     C.GREEN),
        ]
        bar_width = 30
        for i, (label, color) in enumerate(stages):
            filled  = int((i + 1) / len(stages) * bar_width)
            bar     = '█' * filled + '░' * (bar_width - filled)
            pct     = int((i + 1) / len(stages) * 100)
            print(f"  {color}{label}{C.RESET}")
            print(f"  {C.RED}[{bar}]{C.RESET} {C.WHITE}{pct}%{C.RESET}")
            sys.stdout.flush()
            time.sleep(0.45)
            if i < len(stages) - 1:
                # Hapus 2 baris terakhir
                print('[2A[J', end='')
        print()
        time.sleep(0.5)

    def _title_screen(self):
        clear()
        # Logo BIOHAZARD — tiap huruf dirender terpisah agar tidak overflow
        print(f"{C.RED}")
        logo_lines = [
            " ██████╗ ██╗ ██████╗ ██╗  ██╗ █████╗ ███████╗",
            " ██╔══██╗██║██╔═══██╗██║  ██║██╔══██╗╚════██╗",
            " ██████╔╝██║██║   ██║███████║███████║    ██╔╝",
            " ██╔══██╗██║██║   ██║██╔══██║██╔══██║   ██╔╝ ",
            " ██████╔╝██║╚██████╔╝██║  ██║██║  ██║   ██║  ",
            " ╚═════╝ ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝  ",
        ]
        logo_lines2 = [
            " █████╗ ██████╗ ██████╗",
            "██╔══██╗██╔══██╗██╔══██╗",
            "███████║██████╔╝██║  ██║",
            "██╔══██║██╔══██╗██║  ██║",
            "██║  ██║██║  ██║██████╔╝",
            "╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ",
        ]
        for i in range(len(logo_lines)):
            print(f"  {C.RED}{logo_lines[i]}  {logo_lines2[i]}{C.RESET}")
        print(f"{C.RESET}")
        print(f"  {C.RED}{'═'*54}{C.RESET}")
        slow_print("  ROGUELIKE EDITION  ·  NetHack Style  ·  RE Universe", delay=0.02, color=C.YELLOW)
        slow_print("  6 Zona  ·  Desa Pueblo → NEST Core Facility", delay=0.018, color=C.RED)
        slow_print("  Temukan Dr. Ashford.  Hancurkan Umbrella.", delay=0.018, color=C.GRAY)
        print(f"  {C.RED}{'═'*54}{C.RESET}")

        saved = Player.load()

        print(f"\n  {C.GREEN}╔══════════════════╗{C.RESET}")
        print(f"  {C.GREEN}║{C.RESET}  {C.GREEN}[n]{C.RESET} Game Baru      {C.GREEN}║{C.RESET}")
        if saved:
            print(f"  {C.GREEN}║{C.RESET}  {C.CYAN}[c]{C.RESET} Lanjutkan      {C.GREEN}║{C.RESET}")
            print(f"  {C.GREEN}║{C.RESET}     {C.GRAY}{saved.nama} Lv{saved.level} F{saved.floor}{C.RESET}  {C.GREEN}║{C.RESET}")
        print(f"  {C.GREEN}║{C.RESET}  {C.YELLOW}[?]{C.RESET} Help           {C.GREEN}║{C.RESET}")
        print(f"  {C.GREEN}║{C.RESET}  {C.GRAY}[q]{C.RESET} Keluar         {C.GREEN}║{C.RESET}")
        print(f"  {C.GREEN}╚══════════════════╝{C.RESET}")

        while True:
            ch = getch().lower()
            if ch == 'n':
                self._new_game()
                return
            elif ch == 'c' and saved:
                self.player = saved
                # Cek apakah boss terakhir sudah dikalahkan sebelum load
                bosses = getattr(saved, 'bosses_killed', [])
                if MAX_FLOOR in bosses:
                    # Boss floor 6 sudah mati — langsung ending!
                    clear()
                    slow_print(f"\n  Selamat datang kembali, {saved.nama}...", color=C.YELLOW)
                    slow_print(f"  NEMESIS sudah dikalahkan. Misi selesai.", color=C.GREEN)
                    import time; time.sleep(1.5)
                    self._ending()
                    return
                self.load_floor(saved.floor)
                self.run()
                return
            elif ch == '?':
                self.show_help()
                self._title_screen()
                return
            elif ch == 'q':
                sys.exit(0)

    def _new_game(self):
        clear()
        divider('═', 52, C.CYAN)
        print(f"  {C.CYAN}BUAT KARAKTER{C.RESET}")
        divider('═', 52, C.CYAN)

        # Input nama
        try:
            import termios, tty
            fd  = sys.stdin.fileno()
            old = termios.tcgetattr(fd)
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        except: pass

        print(f"\n  {C.YELLOW}Nama karakter:{C.RESET} ", end='', flush=True)
        nama = input().strip() or "Redfield"

        # Pilih kelas
        from data import CLASSES
        print(f"\n  {C.YELLOW}Pilih kelas:{C.RESET}\n")
        keys   = list(CLASSES.keys())
        ckeys  = 'abcdefghij'   # cukup untuk semua kelas
        for i, (k, cls) in enumerate(CLASSES.items()):
            print(f"  {C.YELLOW}[{ckeys[i]}]{C.RESET} {cls['icon']} {C.WHITE}{cls['nama']}{C.RESET}")
            print(f"       {C.GRAY}{cls['deskripsi']}{C.RESET}")
            print(f"       HP:{cls['base_hp']} ATK:{cls['base_atk']} "
                  f"DEF:{cls['base_def']} SPD:{cls['base_spd']}")
            print()

        kelas_id = keys[0]
        while True:
            ch = getch().lower()
            if ch in ckeys[:len(keys)]:
                kelas_id = keys[ckeys.index(ch)]
                break

        self.player = Player(nama, kelas_id)
        cls = CLASSES[kelas_id]
        clear()
        slow_print(f"\n  {cls['icon']} {nama} sang {cls['nama']} siap bertarung!", color=C.GREEN)
        slow_print(f"\n  Raccoon City telah jatuh.", color=C.RED)
        wrap_print(
            f"Selamat datang, {nama}. Virus-T sudah menyebar ke seluruh kota. "
            "Umbrella Corporation menyangkal semua. Tapi kamu tahu kebenarannya. "
            "Dr. Ashford — ilmuwan Umbrella yang membelot — ada di NEST, "
            "jauh di bawah kota. Dia punya data untuk menghentikan semua ini. "
            "Tembus 6 zona. Selamatkan Ashford. Hancurkan Umbrella.",
            color=C.WHITE
        )
        press_any()

        self.play_cutscene('intro')
        self.load_floor(1, show_cutscene=True)
        self.run()
