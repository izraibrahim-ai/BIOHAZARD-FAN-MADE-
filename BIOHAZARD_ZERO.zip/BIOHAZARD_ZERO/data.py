#!/usr/bin/env python3
# data.py — Semua data game: RE Universe Edition

from utils import C

# ══════════════════════════════════════════════════
#  SIMBOL WARNA PETA (NetHack style)
# ══════════════════════════════════════════════════
SYM_COLOR = {
    '@':  C.CYAN + C.BOLD,
    'z':  C.GREEN,
    'C':  C.RED,
    'L':  C.MAGENTA,
    'G':  C.YELLOW,
    'M':  C.BLUE,
    'I':  C.CYAN,
    'D':  C.YELLOW,
    'H':  C.RED,
    'W':  C.MAGENTA,
    'V':  C.RED + C.BOLD,
    'X':  C.RED + C.BOLD,
    'N':  C.RED + C.BOLD + C.BLINK,
    '$':  C.YELLOW,
    '!':  C.MAGENTA,
    ')':  C.WHITE,
    '[':  C.BLUE,
    ',':  C.GREEN,
    '"':  C.YELLOW,
    '%':  C.RED,
    '>':  C.WHITE,
    '<':  C.WHITE,
    '^':  C.RED,
    '·':  C.GRAY + C.DIM,
    '─':  C.GRAY,
    '│':  C.GRAY,
    '┌':  C.GRAY,
    '┐':  C.GRAY,
    '└':  C.GRAY,
    '┘':  C.GRAY,
    '+':  C.YELLOW,
    '/':  C.YELLOW,
    '░':  C.GRAY + C.DIM,
}

# ══════════════════════════════════════════════════
#  CLASS KARAKTER — RE Characters
# ══════════════════════════════════════════════════
CLASSES = {
    'leon': {
        'nama':      'Leon S. Kennedy',
        'icon':      '🔫',
        'deskripsi': 'Agen pemerintah AS. Ahli tembak & combat jarak dekat.',
        'lore':      'Mantan polisi Raccoon City yang selamat. Kini agen khusus POTUS.',
        'base_hp': 110, 'base_atk': 14, 'base_def': 6, 'base_spd': 8,
        'mp': 20,
        'skills': ['suplex', 'tactical_evade'],
    },
    'jill': {
        'nama':      'Jill Valentine',
        'icon':      '🧨',
        'deskripsi': 'Mantan S.T.A.R.S. Alpha. Ahli peledak & survival.',
        'lore':      'Selamat dari Mansion Incident dan Raccoon City. Pendiri BSAA.',
        'base_hp': 100, 'base_atk': 12, 'base_def': 7, 'base_spd': 9,
        'mp': 30,
        'skills': ['grenade', 'guard'],
    },
    'chris': {
        'nama':      'Chris Redfield',
        'icon':      '💪',
        'deskripsi': 'Kapten BSAA. Stamina luar biasa, damage terbesar.',
        'lore':      'Anggota S.T.A.R.S. pertama. Telah melawan bioterrorisme puluhan tahun.',
        'base_hp': 140, 'base_atk': 16, 'base_def': 9, 'base_spd': 5,
        'mp': 10,
        'skills': ['power_strike', 'guard'],
    },
    'ethan': {
        'nama':      'Ethan Winters',
        'icon':      '🩸',
        'deskripsi': 'Sipil dengan regenerasi misterius. HP regen pasif.',
        'lore':      'Terinfeksi Mold tapi masih hidup. Kekuatan aneh mengalir di tubuhnya.',
        'base_hp': 120, 'base_atk': 11, 'base_def': 5, 'base_spd': 7,
        'mp': 40,
        'skills': ['mold_regen', 'antidote'],
    },
}

# ══════════════════════════════════════════════════
#  SKILLS
# ══════════════════════════════════════════════════
SKILLS = {
    'suplex':         {'nama': 'Suplex',          'mp': 0,  'efek': 'damage',   'nilai': 1.8,
                       'deskripsi': 'Leon suplex musuh! DMG x1.8'},
    'tactical_evade': {'nama': 'Tactical Evade',  'mp': 10, 'efek': 'evade',    'nilai': 0.85,
                       'deskripsi': 'Dodge 85% serangan ronde ini'},
    'evade':          {'nama': 'Tactical Evade',  'mp': 10, 'efek': 'evade',    'nilai': 0.85,
                       'deskripsi': 'Dodge 85% serangan ronde ini'},
    'grenade':        {'nama': 'Flash Grenade',   'mp': 15, 'efek': 'stun',     'nilai': 0,
                       'deskripsi': 'Stun musuh — tidak bisa serang 1 ronde'},
    'guard':          {'nama': 'Guard',           'mp': 0,  'efek': 'defend',   'nilai': 0.5,
                       'deskripsi': 'Kurangi damage 50% ronde ini'},
    'slash':          {'nama': 'Slash',           'mp': 0,  'efek': 'damage',   'nilai': 1.5,
                       'deskripsi': 'Tebasan kuat. DMG x1.5'},
    'power_strike':   {'nama': 'Power Strike',    'mp': 0,  'efek': 'damage',   'nilai': 2.0,
                       'deskripsi': 'Pukulan keras Chris. DMG x2.0'},
    'aimed_shot':     {'nama': 'Aimed Shot',      'mp': 10, 'efek': 'damage',   'nilai': 2.0,
                       'deskripsi': 'Tembakan presisi. DMG x2, critical 50%'},
    'mold_regen':     {'nama': 'Mold Regen',      'mp': 20, 'efek': 'heal',     'nilai': 50,
                       'deskripsi': 'Mold di tubuh Ethan memulihkan 50 HP'},
    'antidote':       {'nama': 'First Aid',       'mp': 15, 'efek': 'antidote', 'nilai': 0,
                       'deskripsi': 'Sembuhkan racun & bleeding seketika'},
    'heal':           {'nama': 'Heal',            'mp': 15, 'efek': 'heal',     'nilai': 40,
                       'deskripsi': 'Pulihkan 40 HP'},
}

# ══════════════════════════════════════════════════
#  MUSUH — RE Universe per floor
# ══════════════════════════════════════════════════
ENEMY_POOL = {
    1: [
        {'nama': 'Zombie',      'sym': 'z', 'hp': 45,  'atk': 8,  'def': 2,  'xp': 15, 'gold': (5,15),
         'drop': ('!', 0.35), 'status': None,
         'deskripsi': 'Warga Raccoon City yang terinfeksi Virus-T. Lambat tapi gigitannya mematikan.'},
        {'nama': 'Cerberus',    'sym': 'D', 'hp': 30,  'atk': 12, 'def': 1,  'xp': 18, 'gold': (3,12),
         'drop': (',', 0.3),  'status': 'bleed',
         'deskripsi': 'Anjing Doberman terinfeksi Virus-T. Cepat dan ganas, mengincar leher.'},
        {'nama': 'Ganado',      'sym': 'G', 'hp': 55,  'atk': 10, 'def': 3,  'xp': 20, 'gold': (8,20),
         'drop': (')', 0.2),  'status': None,
         'deskripsi': 'Penduduk desa terinfeksi Plagas. Masih bisa menggunakan senjata dan berkomunikasi.'},
    ],
    3: [
        {'nama': 'Licker',      'sym': 'L', 'hp': 70,  'atk': 16, 'def': 3,  'xp': 35, 'gold': (12,28),
         'drop': ('!', 0.4),  'status': 'poison',
         'deskripsi': 'Zombie bermutasi lanjut. Buta tapi peka suara. Lidahnya panjang dan beracun.'},
        {'nama': 'Crimson Head','sym': 'C', 'hp': 80,  'atk': 20, 'def': 2,  'xp': 40, 'gold': (15,30),
         'drop': (')', 0.25), 'status': 'bleed',
         'deskripsi': 'Zombie yang bangkit kembali setelah mati. Lebih cepat, lebih agresif, lebih lapar.'},
        {'nama': 'Plagas Host', 'sym': 'I', 'hp': 60,  'atk': 14, 'def': 4,  'xp': 30, 'gold': (10,22),
         'drop': ('[', 0.2),  'status': 'poison',
         'deskripsi': 'Tubuh manusia dikuasai sepenuhnya parasit Plagas. Parasit keluar dari leher saat terluka.'},
    ],
    5: [
        {'nama': 'Hunter Alpha','sym': 'H', 'hp': 100, 'atk': 22, 'def': 7,  'xp': 55, 'gold': (20,40),
         'drop': (')', 0.3),  'status': 'bleed',
         'deskripsi': 'B.O.W. reptilian Umbrella. Cakar tajamnya bisa memenggal kepala dalam satu tebasan.'},
        {'nama': 'Molded',      'sym': 'M', 'hp': 90,  'atk': 18, 'def': 6,  'xp': 45, 'gold': (15,35),
         'drop': ('!', 0.45), 'status': None,
         'deskripsi': 'Manusia yang dikonsumsi Mold sepenuhnya. Bentuknya tidak lagi manusiawi.'},
        {'nama': 'Verdugo',     'sym': 'V', 'hp': 130, 'atk': 28, 'def': 10, 'xp': 70, 'gold': (30,55),
         'drop': ('"', 0.3),  'status': 'poison',
         'deskripsi': 'Bodyguard Salazar. Exoskeleton sekeras baja. Ekornya bisa menembus dinding beton.'},
    ],
    'boss_2': {
        'nama': 'El Gigante', 'sym': 'X',
        'hp': 260, 'atk': 30, 'def': 10, 'xp': 180, 'gold': (60,90),
        'drop': ('[', 1.0), 'status': 'bleed', 'is_boss': True,
        'deskripsi': 'Manusia raksasa dimutasi Plagas. Tinggi 5 meter. Satu hantaman bisa menghancurkan bangunan.',
    },
    'boss_4': {
        'nama': 'Mr. X — Tyrant T-00', 'sym': 'X',
        'hp': 380, 'atk': 38, 'def': 14, 'xp': 280, 'gold': (90,130),
        'drop': (')', 1.0), 'status': None, 'is_boss': True,
        'deskripsi': 'Tyrant model T-00. Tidak tidur. Tidak lelah. Tidak bisa dinegosiasi. Selalu mencarimu.',
    },
    'boss_6': {
        'nama': 'NEMESIS-T Type', 'sym': 'N',
        'hp': 600, 'atk': 55, 'def': 20, 'xp': 600, 'gold': (180,250),
        'drop': ('"', 1.0), 'status': 'poison', 'is_boss': True,
        'deskripsi': 'Tyrant dengan NE-Alpha Parasite dicangkokkan ke otaknya. Satu tujuan: S.T.A.R.S.',
    },
}

def get_enemy_pool(floor):
    if floor % 2 == 0 and floor > 0:
        key = f'boss_{floor}'
        if key in ENEMY_POOL:
            return [ENEMY_POOL[key]]
    for threshold in sorted([k for k in ENEMY_POOL if isinstance(k, int)], reverse=True):
        if floor >= threshold:
            return ENEMY_POOL[threshold]
    return ENEMY_POOL[1]

# ══════════════════════════════════════════════════
#  ITEM TABLE — RE Universe
# ══════════════════════════════════════════════════
ITEM_TABLE = {
    '!': [
        {
            'nama': 'Green Herb',
            'efek': 'heal', 'nilai': 30, 'rarity': 38,
            'asal': 'Tanaman herbal alami — tumbuh liar di Eropa Tengah.',
            'guna': 'Pulihkan 30 HP. Item penyembuh paling dasar di Raccoon City.',
        },
        {
            'nama': 'Red+Green Herb',
            'efek': 'heal', 'nilai': 80, 'rarity': 18,
            'asal': 'Ramuan campuran Green Herb dan Red Herb.',
            'guna': 'Pulihkan 80 HP. Efek lebih kuat dari Green Herb biasa.',
        },
        {
            'nama': 'Blue+Green Herb',
            'efek': 'heal', 'nilai': 40, 'rarity': 14, 'bonus': 'antidote',
            'asal': 'Campuran Green Herb dan Blue Herb langka.',
            'guna': 'Pulihkan 40 HP + sembuhkan racun dan bleeding sekaligus.',
        },
        {
            'nama': 'Mixed Herb (G+R+B)',
            'efek': 'heal', 'nilai': 150, 'rarity': 5,
            'asal': 'Ramuan tiga herb dicampur secara khusus.',
            'guna': 'Pulihkan 150 HP + sembuhkan semua status negatif.',
        },
        {
            'nama': 'First Aid Spray',
            'efek': 'heal', 'nilai': 999, 'rarity': 3,
            'asal': 'Produksi Umbrella Medical Division. Semprot aerosol.',
            'guna': 'Pulihkan HP penuh seketika. Item paling berharga.',
        },
        {
            'nama': 'Antidote',
            'efek': 'antidote', 'nilai': 0, 'rarity': 15,
            'asal': 'Suntikan antitoksin standar militer AS.',
            'guna': 'Sembuhkan racun dan bleeding. Tidak ada efek HP.',
        },
        {
            'nama': 'Hemostatic Agent',
            'efek': 'antidote', 'nilai': 0, 'rarity': 7,
            'asal': 'Agen hemostatik dari kit medis lapangan BSAA.',
            'guna': 'Hentikan bleeding seketika. Efektif untuk luka sayatan.',
        },
    ],
    ')': [
        {
            'nama': 'Combat Knife',
            'efek': 'weapon', 'atk': 7, 'rarity': 32,
            'asal': 'Pisau lapangan standar militer. Ringan dan andal.',
            'guna': 'Senjata jarak dekat. ATK +7. Tidak butuh amunisi.',
        },
        {
            'nama': 'Matilda (Pistol)',
            'efek': 'weapon', 'atk': 16, 'rarity': 20,
            'asal': 'Pistol modifikasi favoritLeon S. Kennedy. Kaliber 9mm.',
            'guna': 'Pistol serba guna. ATK +16. Akurasi dan kecepatan tinggi.',
        },
        {
            'nama': 'SIG Sauer P226',
            'efek': 'weapon', 'atk': 14, 'rarity': 18,
            'asal': 'Pistol standar operasional S.T.A.R.S. dan BSAA.',
            'guna': 'Pistol reliable. ATK +14. Dipakai Chris dan Jill.',
        },
        {
            'nama': 'W-870 Shotgun',
            'efek': 'weapon', 'atk': 35, 'rarity': 10,
            'asal': 'Shotgun pump-action. Ditemukan di gudang kastil Salazar.',
            'guna': 'Damage besar di jarak dekat. ATK +35. Sangat efektif vs Boss.',
        },
        {
            'nama': 'Grenade Launcher',
            'efek': 'weapon', 'atk': 50, 'rarity': 6,
            'asal': 'Pelontar granat militer. Sering ditemukan di fasilitas Umbrella.',
            'guna': 'Damage area besar. ATK +50. Efektif lawan kelompok musuh.',
        },
        {
            'nama': 'Lightning Hawk Magnum',
            'efek': 'weapon', 'atk': 65, 'rarity': 4,
            'asal': 'Magnum Desert Eagle modifikasi. Senjata andalan para veteran.',
            'guna': 'Damage sangat tinggi. ATK +65. Ideal untuk boss fight.',
        },
        {
            'nama': 'Broken Butterfly Mag.',
            'efek': 'weapon', 'atk': 75, 'rarity': 2,
            'asal': 'Revolver magnum mewah. Ditemukan di kastil Salazar.',
            'guna': 'Senjata terkuat kedua. ATK +75. Satu tembakan bisa fatal.',
        },
        {
            'nama': 'Rocket Launcher',
            'efek': 'weapon', 'atk': 120, 'rarity': 1,
            'asal': 'RPG militer. Satu-satunya senjata yang pasti matikan Tyrant.',
            'guna': 'Damage tertinggi. ATK +120. Senjata pamungkas melawan boss.',
        },
    ],
    '[': [
        {
            'nama': 'Tactical Vest',
            'efek': 'armor', 'def': 7, 'rarity': 35,
            'asal': 'Rompi taktis standar polisi. Ringan dan fleksibel.',
            'guna': 'Proteksi dasar. DEF +7. Cocok untuk early game.',
        },
        {
            'nama': 'S.T.A.R.S. Uniform',
            'efek': 'armor', 'def': 10, 'rarity': 22,
            'asal': 'Seragam dinas S.T.A.R.S. Alpha Team. Tahan peluru ringan.',
            'guna': 'Armor menengah. DEF +10. Seimbang antara proteksi dan gerak.',
        },
        {
            'nama': 'Kevlar Suit',
            'efek': 'armor', 'def': 14, 'rarity': 18,
            'asal': 'Setelan Kevlar grade militer. Dipakai unit anti-teror.',
            'guna': 'Proteksi tinggi. DEF +14. Tahan terhadap sebagian besar serangan.',
        },
        {
            'nama': 'BSAA Combat Armor',
            'efek': 'armor', 'def': 20, 'rarity': 10,
            'asal': 'Armor tempur BSAA. Dirancang khusus untuk bioterrorisme.',
            'guna': 'Armor berat. DEF +20. Khusus operator anti-bioweapon.',
        },
        {
            'nama': 'Hazmat Suit',
            'efek': 'armor', 'def': 25, 'rarity': 5,
            'asal': 'Setelan Hazmat Umbrella Research. Anti-kontaminasi penuh.',
            'guna': 'Proteksi sangat tinggi. DEF +25. Tahan racun dan infeksi.',
        },
        {
            'nama': 'Umbrella Prototype Suit',
            'efek': 'armor', 'def': 35, 'rarity': 2,
            'asal': 'Prototype armor eksperimental Umbrella. Bahan komposit rahasia.',
            'guna': 'Armor terkuat. DEF +35. Hanya ada satu di seluruh fasilitas.',
        },
    ],
    ',': [
        {
            'nama': 'Gunpowder (ATK+)',
            'efek': 'buff_atk', 'nilai': 4, 'rarity': 30,
            'asal': 'Bubuk mesiu murni dari amunisi yang dimodifikasi.',
            'guna': 'ATK permanen +4. Efek tidak hilang sampai akhir game.',
        },
        {
            'nama': 'Field Ration',
            'efek': 'food', 'nilai': 25, 'rarity': 40,
            'asal': 'Ransum lapangan militer. Kalori tinggi, tahan lama.',
            'guna': 'Pulihkan 25 HP. Pemulihan ringan saat situasi darurat.',
        },
        {
            'nama': 'Protein Bar',
            'efek': 'food', 'nilai': 40, 'rarity': 30,
            'asal': 'Suplemen protein dari kit survival operator khusus.',
            'guna': 'Pulihkan 40 HP. Lebih efektif dari ransum lapangan.',
        },
    ],
    '"': [
        {
            'nama': 'Umbrella Keycard',
            'efek': 'amulet', 'bonus': 'def', 'nilai': 12, 'rarity': 20,
            'asal': 'Kartu akses fasilitas Umbrella. Mengandung chip keamanan.',
            'guna': 'DEF permanen +12. Chip di dalamnya memperkuat pelindung tubuh.',
        },
        {
            'nama': 'Plagas Parasite Shard',
            'efek': 'amulet', 'bonus': 'atk', 'nilai': 15, 'rarity': 15,
            'asal': 'Pecahan parasit Plagas yang telah mati dan mengeras.',
            'guna': 'ATK permanen +15. Energi biologis Plagas meningkatkan kekuatan.',
        },
        {
            'nama': 'Mold Fragment',
            'efek': 'amulet', 'bonus': 'hp', 'nilai': 40, 'rarity': 15,
            'asal': 'Potongan Mold dari Baker Estate. Masih aktif secara biologis.',
            'guna': 'Max HP +40. Regenerasi Mold memperkuat kapasitas hidup.',
        },
    ],
}


def random_item(sym):
    import random
    pool = ITEM_TABLE.get(sym, [])
    if not pool: return None
    weights = [i['rarity'] for i in pool]
    return random.choices(pool, weights=weights, k=1)[0].copy()

def random_gold(floor):
    import random
    base = floor * 8
    return random.randint(base, base + 25)

# ══════════════════════════════════════════════════
#  FLOOR INFO — Lokasi RE
# ══════════════════════════════════════════════════
FLOOR_INFO = {
    1: {'nama': 'Desa Pueblo',            'simbol': '🌾',
        'flavor': 'Desa mati. Asap mengepul dari rumah-rumah yang terbakar.'},
    2: {'nama': 'Gereja Desa',            'simbol': '⛪',
        'flavor': 'Lonceng berdentang sendiri. Tidak ada yang menyambut kecuali kematian.'},
    3: {'nama': 'Kastil Salazar',         'simbol': '🏰',
        'flavor': 'Lorong kastil megah. Licker merayap di langit-langit.'},
    4: {'nama': 'Ruang Bawah Kastil',     'simbol': '🧪',
        'flavor': 'Lab rahasia Salazar. Bau bahan kimia Plagas menyesakkan napas.'},
    5: {'nama': 'Fasilitas Umbrella',     'simbol': '☣',
        'flavor': 'Lab steril yang kini penuh darah. Komputer masih menyala tanpa operator.'},
    6: {'nama': 'NEST — Core Facility',   'simbol': '💀',
        'flavor': 'Di sini Virus-T lahir. Di sini semua berakhir.'},
}

def get_floor_info(floor):
    return FLOOR_INFO.get(floor, {
        'nama': f'Area {floor}', 'simbol': '?',
        'flavor': 'Gelap. Sunyi. Sangat berbahaya.',
    })

# ══════════════════════════════════════════════════
#  CUTSCENE STORY
# ══════════════════════════════════════════════════
CUTSCENES = {
    'intro': {
        'judul': '[ TRANSMISI DARURAT — OPERASI RACCOON ]',
        'warna': C.RED,
        'teks': [
            "RACCOON CITY — 24 jam setelah wabah.",
            "",
            "Virus-T menyebar ke seluruh kota dalam semalam.",
            "Umbrella Corporation menyangkal. Pemerintah diam.",
            "Tapi kamu tahu kebenarannya.",
            "",
            "Seorang informan menyebut nama: DR. ASHFORD.",
            "Ilmuwan Umbrella yang membelot. Dia punya data untuk",
            "menghentikan semua ini.",
            "Lokasi terakhir: Fasilitas NEST, jauh di bawah kota.",
            "",
            "Misi: Tembus 6 zona. Selamatkan Ashford.",
            "Hancurkan NEST dari dalam.",
            "",
            "Tidak ada backup. Tidak ada evakuasi.",
            "Hanya kamu.",
        ],
    },
    'enter_1': {
        'judul': '[ ZONA 1 — DESA PUEBLO ]',
        'warna': C.YELLOW,
        'teks': [
            "Helikopter menurunkanmu di pinggiran desa.",
            "Sunyi. Terlalu sunyi untuk siang hari.",
            "",
            "Lalu sesosok manusia tersaruk-saruk ke arahmu.",
            "Mata kosong. Mulut menganga. Bukan manusia lagi.",
            "",
            "Radio: \"Hati-hati. Warga desa terinfeksi Plagas.",
            "Mereka masih bisa menggunakan senjata.",
            "Jangan remehkan mereka.\"",
        ],
    },
    'enter_2': {
        'judul': '[ ZONA 2 — GEREJA DESA ]',
        'warna': C.YELLOW,
        'teks': [
            "Kamu berhasil menembus desa.",
            "Tapi sesuatu yang sangat besar menghalangi jalan.",
            "",
            "EL GIGANTE.",
            "Manusia yang dimutasi Plagas hingga sebesar rumah.",
            "Satu hantamannya cukup untuk mengubur kamu.",
            "",
            "Informan di radio:",
            "\"Ada Plagas di punggungnya. Tembak Plagas-nya.\"",
        ],
    },
    'enter_3': {
        'judul': '[ ZONA 3 — KASTIL SALAZAR ]',
        'warna': C.MAGENTA,
        'teks': [
            "Kastil Ramon Salazar. Keluarga bangsawan yang sudah gila.",
            "",
            "Licker merayap di langit-langit.",
            "Crimson Head bangkit dari bangkai yang kamu tinggalkan.",
            "JANGAN biarkan zombie terlalu lama —",
            "mereka AKAN bermutasi jadi Crimson Head.",
            "",
            "Radio: \"Mr. X sudah melacak posisimu.",
            "Tyrant T-00 sedang dalam perjalanan.\"",
        ],
    },
    'enter_4': {
        'judul': '[ ZONA 4 — RUANG BAWAH KASTIL ]',
        'warna': C.MAGENTA,
        'teks': [
            "Basement kastil. Lab pribadi Salazar.",
            "",
            "MR. X menunggumu di bawah.",
            "",
            "Tyrant T-00. Tidak tidur. Tidak lelah.",
            "Tidak bisa dibunuh — hanya dilambatkan.",
            "",
            "Ashford di radio: \"Kamu dekat. Tapi NEMESIS",
            "sudah diaktifkan. Mereka mengirim yang terbaik.\"",
        ],
    },
    'enter_5': {
        'judul': '[ ZONA 5 — FASILITAS UMBRELLA ]',
        'warna': C.CYAN,
        'teks': [
            "Fasilitas steril. Kini penuh darah.",
            "Para ilmuwan Umbrella jadi percobaan sendiri.",
            "",
            "Molded — manusia dikonsumsi Mold sepenuhnya.",
            "Hunter Alpha — reptilian B.O.W. pencabut kepala.",
            "Verdugo — bodyguard berkaki enam, exoskeleton keras.",
            "",
            "Radio Ashford terputus-putus:",
            "\"Aku di NEST... lantai paling bawah...",
            "NEMESIS sudah... dekat... cepat...\"",
        ],
    },
    'enter_6': {
        'judul': '[ ZONA 6 — NEST CORE FACILITY ]',
        'warna': C.RED,
        'teks': [
            "NEST. Fasilitas terdalam Umbrella.",
            "Tempat Virus-T pertama kali dikultur.",
            "Tempat Mold pertama kali dicangkokkan ke manusia hidup.",
            "",
            "Di ujung sana — NEMESIS.",
            "",
            "NE-Alpha Parasite dicangkokkan ke otak Tyrant.",
            "Dia bisa berlari. Dia bisa berpikir.",
            "Dia punya satu tujuan: MEMBUNUH S.T.A.R.S.",
            "",
            "Kamu adalah harapan terakhir.",
            "Selesaikan ini.",
        ],
    },
    'boss_win_2': {
        'judul': '[ EL GIGANTE DIKALAHKAN ]',
        'warna': C.GREEN,
        'teks': [
            "El Gigante jatuh. Tanah bergetar.",
            "",
            "Di antara reruntuhannya, kamu temukan kunci gereja.",
            "Dan catatan tangan Salazar:",
            "",
            "\"Percobaan #47 gagal. Plagas terlalu agresif.",
            "Kirim specimen ke lab kastil. — R. Salazar\"",
            "",
            "Ini bukan kecelakaan. Ini disengaja.",
        ],
    },
    'boss_win_4': {
        'judul': '[ MR. X DIKALAHKAN ]',
        'warna': C.GREEN,
        'teks': [
            "Tyrant T-00 akhirnya tumbang.",
            "",
            "Di terminal komputer ruangannya:",
            "File 'PROJECT NEMESIS' terbuka.",
            "",
            "\"NEMESIS-T Type. Target: Semua anggota S.T.A.R.S.",
            "Diaktifkan: 3 jam lalu. Lokasi: NEST Core.\"",
            "",
            "Bergeraklah lebih cepat.",
        ],
    },
    'boss_win_6': {
        'judul': '[ NEMESIS DIKALAHKAN — MISI SELESAI ]',
        'warna': C.YELLOW,
        'teks': [
            "NEMESIS roboh. Parasit NE-Alpha terlepas. Mati.",
            "",
            "Dr. Ashford keluar dari balik lemari besi.",
            "Tua. Lelah. Tapi masih hidup.",
            "",
            "\"Kamu datang... aku sudah tidak berharap.\"",
            "",
            "Dia menyerahkan hard drive.",
            "\"Formula Virus-T. Antivirus. Semua ada di sini.",
            "Bawa ke luar. Sebar ke dunia.",
            "Umbrella harus dihancurkan.\"",
            "",
            "Alarm berbunyi. Self-destruct: 10 menit.",
            "",
            "Kamu dan Ashford berlari keluar.",
            "Di belakangmu, NEST — dan semua kejahatan Umbrella —",
            "musnah dalam ledakan.",
            "",
            "Ini baru permulaan.",
        ],
    },
}

# ══════════════════════════════════════════════════
#  TRAP MESSAGES — RE flavor
# ══════════════════════════════════════════════════
TRAP_MSG = [
    "KLIK! Jebakan panah Umbrella! Darahmu mengalir deras!",
    "Lantai metal — electro trap Umbrella! Listrik mengalir ke tubuhmu!",
    "Gas Nemesis menyembur dari ventilasi! Racun memenuhi paru-parumu!",
    "Bear trap tersembunyi di reruntuhan! Kakimu terjepit!",
    "Wire trap! Kawat baja menyayat tubuhmu sebelum kamu lepas!",
]
